# Tableau de Bord PDR/SRAT - Région Béni Mellal-Khénifra

Tableau de bord interactif pour le suivi et l'évaluation du Programme de Développement Régional (PDR) et du Schéma Régional d'Aménagement du Territoire (SRAT) de la région de Béni Mellal-Khénifra.

## Fonctionnalités

- **Navigation entre tableaux de bord** : Basculer entre PDR et SRAT
- **Visualisations interactives** : Graphiques Chart.js pour les indicateurs
- **Interface responsive** : Compatible mobile et desktop
- **Données réalistes** : Indicateurs et métriques basés sur les programmes réels

## Technologies

- React 18
- Vite
- Tailwind CSS
- Chart.js
- Font Awesome

## Installation

```bash
npm install
npm run dev
```

## Déploiement

```bash
npm run build
```

Les fichiers de production seront dans le dossier `dist/`.
