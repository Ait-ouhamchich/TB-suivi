import React from 'react';
import indicatorsVisualization from '../assets/indicators_visualization.png';
import IndicatorChart from './charts/IndicatorChart';
import { indicatorTrendsData, indicatorsData } from '../data/mockData';

const IndicatorsEnhanced = () => {
  const indicatorCategories = [
    {
      category: 'Économie',
      icon: 'fas fa-chart-line',
      color: 'blue',
      indicators: indicatorsData.economic
    },
    {
      category: 'Social',
      icon: 'fas fa-users',
      color: 'green',
      indicators: indicatorsData.social
    },
    {
      category: 'Environnement',
      icon: 'fas fa-leaf',
      color: 'purple',
      indicators: indicatorsData.environmental
    }
  ];

  const getColorClasses = (color) => {
    const colors = {
      blue: 'text-blue-600 bg-blue-100 border-blue-200',
      green: 'text-green-600 bg-green-100 border-green-200',
      purple: 'text-purple-600 bg-purple-100 border-purple-200'
    };
    return colors[color] || 'text-gray-600 bg-gray-100 border-gray-200';
  };

  const getStatusIcon = (current, target) => {
    const progress = (current / target) * 100;
    if (progress >= 90) return <i className="fas fa-check-circle text-green-500"></i>;
    if (progress >= 70) return <i className="fas fa-clock text-yellow-500"></i>;
    return <i className="fas fa-exclamation-triangle text-red-500"></i>;
  };

  const calculateProgress = (current, target) => {
    return Math.min(100, Math.round((current / target) * 100));
  };

  const getProgressColor = (progress) => {
    if (progress >= 90) return 'bg-green-500';
    if (progress >= 70) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  // Calcul des statistiques globales
  const allIndicators = [...indicatorsData.economic, ...indicatorsData.social, ...indicatorsData.environmental];
  const totalIndicators = allIndicators.length;
  const onTrack = allIndicators.filter(ind => calculateProgress(ind.current, ind.target) >= 70).length;
  const achieved = allIndicators.filter(ind => calculateProgress(ind.current, ind.target) >= 90).length;
  const needsAttention = allIndicators.filter(ind => calculateProgress(ind.current, ind.target) < 70).length;

  return (
    <div className="space-y-6">
      {/* En-tête de section */}
      <div className="section-header">
        <h2 className="text-3xl font-bold text-gray-800">Indicateurs de Performance</h2>
        <p className="text-gray-600 mt-2">Suivi détaillé des indicateurs SMART par catégorie</p>
      </div>

      {/* Statistiques globales */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-blue-600 mb-2">{totalIndicators}</div>
          <div className="text-gray-600">Indicateurs Total</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-green-600 mb-2">{onTrack}</div>
          <div className="text-gray-600">En Bonne Voie</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-yellow-600 mb-2">{achieved}</div>
          <div className="text-gray-600">Objectifs Atteints</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-red-600 mb-2">{needsAttention}</div>
          <div className="text-gray-600">Nécessitent Attention</div>
        </div>
      </div>

      {/* Graphique de tendance */}
      <div className="pdr-card rounded-lg p-6 pdr-shadow mb-8">
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-chart-line mr-2 pdr-accent"></i>
          Évolution des Indicateurs Clés
        </h3>
        <IndicatorChart 
          data={indicatorTrendsData} 
          title="Taux de Croissance des Entreprises (%)"
        />
      </div>

      {/* Visualisation des indicateurs */}
      <div className="pdr-card rounded-lg p-6 pdr-shadow mb-8">
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-chart-bar mr-2 pdr-accent"></i>
          Tableau de Bord Visuel
        </h3>
        <div className="text-center">
          <img 
            src={indicatorsVisualization} 
            alt="Visualisation des indicateurs" 
            className="w-full max-w-4xl mx-auto rounded-lg border-2 pdr-border"
          />
        </div>
      </div>

      {/* Indicateurs par catégorie */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {indicatorCategories.map((category, index) => (
          <div key={index} className="pdr-card rounded-lg p-6 pdr-shadow">
            <div className="flex items-center mb-4">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center mr-3 ${getColorClasses(category.color)}`}>
                <i className={category.icon}></i>
              </div>
              <h3 className="text-xl font-bold text-gray-800">{category.category}</h3>
            </div>

            <div className="space-y-4">
              {category.indicators.map((indicator, idx) => {
                const progress = calculateProgress(indicator.current, indicator.target);
                return (
                  <div key={idx} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-gray-800 text-sm">{indicator.name}</span>
                      {getStatusIcon(indicator.current, indicator.target)}
                    </div>
                    
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-gray-600">
                        Actuel: <strong>{indicator.current}{indicator.unit}</strong>
                      </span>
                      <span className="text-sm text-gray-600">
                        Cible: <strong>{indicator.target}{indicator.unit}</strong>
                      </span>
                    </div>

                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full transition-all duration-300 ${getProgressColor(progress)}`}
                        style={{ width: `${progress}%` }}
                      ></div>
                    </div>
                    
                    <div className="text-right mt-1">
                      <span className="text-xs text-gray-500">
                        {progress}% de l'objectif
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Analyse de performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="pdr-card rounded-lg p-6 pdr-shadow">
          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-trophy mr-2 text-yellow-500"></i>
            Meilleurs Performances
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
              <span className="text-sm font-medium text-gray-800">Accès à l'eau potable</span>
              <span className="text-sm font-bold text-green-600">94% (Cible: 98%)</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
              <span className="text-sm font-medium text-gray-800">Taux de scolarisation</span>
              <span className="text-sm font-bold text-green-600">92% (Cible: 95%)</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
              <span className="text-sm font-medium text-gray-800">Croissance des entreprises</span>
              <span className="text-sm font-bold text-green-600">85% (Cible: 10%)</span>
            </div>
          </div>
        </div>

        <div className="pdr-card rounded-lg p-6 pdr-shadow">
          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-exclamation-triangle mr-2 text-red-500"></i>
            Points d'Amélioration
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
              <span className="text-sm font-medium text-gray-800">Énergies renouvelables</span>
              <span className="text-sm font-bold text-red-600">70% (Cible: 50%)</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
              <span className="text-sm font-medium text-gray-800">Fermes durables</span>
              <span className="text-sm font-bold text-yellow-600">73% (Cible: 30%)</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
              <span className="text-sm font-medium text-gray-800">Déchets traités</span>
              <span className="text-sm font-bold text-yellow-600">81% (Cible: 80%)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Méthodologie SMART */}
      <div className="pdr-card rounded-lg p-6 pdr-shadow">
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-bullseye mr-2 pdr-accent"></i>
          Méthodologie SMART
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-blue-600 mb-2">S</div>
            <div className="text-sm font-medium text-gray-800 mb-1">Spécifiques</div>
            <div className="text-xs text-gray-600">Objectifs clairs et précis</div>
          </div>
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-green-600 mb-2">M</div>
            <div className="text-sm font-medium text-gray-800 mb-1">Mesurables</div>
            <div className="text-xs text-gray-600">Quantifiables et vérifiables</div>
          </div>
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-purple-600 mb-2">A</div>
            <div className="text-sm font-medium text-gray-800 mb-1">Atteignables</div>
            <div className="text-xs text-gray-600">Réalistes et faisables</div>
          </div>
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-orange-600 mb-2">R</div>
            <div className="text-sm font-medium text-gray-800 mb-1">Réalistes</div>
            <div className="text-xs text-gray-600">Adaptés au contexte</div>
          </div>
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-red-600 mb-2">T</div>
            <div className="text-sm font-medium text-gray-800 mb-1">Temporels</div>
            <div className="text-xs text-gray-600">Délais définis</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IndicatorsEnhanced;

