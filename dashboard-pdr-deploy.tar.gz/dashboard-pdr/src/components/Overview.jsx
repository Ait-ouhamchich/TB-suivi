import React from 'react';
import dashboardMockup from '../assets/dashboard_mockup.png';

const Overview = () => {
  const kpis = [
    { title: 'Projets en cours', value: '127', icon: 'fas fa-project-diagram', color: 'text-blue-600' },
    { title: 'Budget exécuté', value: '68%', icon: 'fas fa-coins', color: 'text-green-600' },
    { title: 'Indicateurs suivis', value: '26', icon: 'fas fa-chart-line', color: 'text-purple-600' },
    { title: 'Axes stratégiques', value: '13', icon: 'fas fa-bullseye', color: 'text-orange-600' }
  ];

  const axesProgress = [
    { name: 'Industrie, Commerce et Services', progress: 75 },
    { name: 'Agriculture, Élevage et Eaux et Forêts', progress: 82 },
    { name: 'Tourisme', progress: 65 },
    { name: 'Artisanat et Économie Solidaire', progress: 58 },
    { name: 'Urbanisme et Aménagement', progress: 71 }
  ];

  return (
    <div className="space-y-6">
      {/* En-tête de section */}
      <div className="section-header">
        <h2 className="text-3xl font-bold text-gray-800">Vue d'ensemble du PDR</h2>
        <p className="text-gray-600 mt-2">Synthèse des indicateurs clés de performance et état d'avancement global</p>
      </div>

      {/* KPIs principaux */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpis.map((kpi, index) => (
          <div key={index} className="pdr-card rounded-lg p-6 text-center pdr-shadow">
            <div className={`text-4xl mb-3 ${kpi.color}`}>
              <i className={kpi.icon}></i>
            </div>
            <div className="text-3xl font-bold text-gray-800 mb-2">{kpi.value}</div>
            <div className="text-gray-600 font-medium">{kpi.title}</div>
          </div>
        ))}
      </div>

      {/* Contenu principal en deux colonnes */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Avancement par axes */}
        <div className="pdr-card rounded-lg p-6 pdr-shadow">
          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-chart-bar mr-2 pdr-accent"></i>
            Avancement par Axe Stratégique
          </h3>
          <div className="space-y-4">
            {axesProgress.map((axe, index) => (
              <div key={index}>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-gray-700">{axe.name}</span>
                  <span className="text-sm font-bold text-gray-800">{axe.progress}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="progress-bar h-2 rounded-full transition-all duration-300"
                    style={{ width: `${axe.progress}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Aperçu du tableau de bord */}
        <div className="pdr-card rounded-lg p-6 pdr-shadow">
          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-desktop mr-2 pdr-accent"></i>
            Interface du Tableau de Bord
          </h3>
          <div className="relative">
            <img 
              src={dashboardMockup} 
              alt="Aperçu du tableau de bord" 
              className="w-full h-auto rounded-lg border-2 pdr-border"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-lg"></div>
          </div>
          <p className="text-gray-600 mt-3 text-sm">
            Interface intuitive avec navigation claire et visualisations interactives
          </p>
        </div>
      </div>

      {/* Statistiques rapides */}
      <div className="pdr-card rounded-lg p-6 pdr-shadow">
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-info-circle mr-2 pdr-accent"></i>
          Informations Clés
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600 mb-2">2022-2027</div>
            <div className="text-gray-600">Période du PDR</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600 mb-2">5 Provinces</div>
            <div className="text-gray-600">Couverture territoriale</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600 mb-2">2.8M</div>
            <div className="text-gray-600">Population bénéficiaire</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Overview;

