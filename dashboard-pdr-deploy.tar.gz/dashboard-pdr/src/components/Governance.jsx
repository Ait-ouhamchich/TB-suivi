import React from 'react';

const Governance = () => {
  const stakeholders = [
    {
      name: 'Conseil Régional',
      role: 'Pilotage et validation',
      icon: 'fas fa-university',
      color: 'blue',
      responsibilities: ['Validation des orientations', 'Suivi budgétaire', 'Coordination générale']
    },
    {
      name: 'Ministères Sectoriels',
      role: 'Mise en œuvre technique',
      icon: 'fas fa-building',
      color: 'green',
      responsibilities: ['Exécution des projets', 'Fourniture des données', 'Expertise sectorielle']
    },
    {
      name: 'Collectivités Territoriales',
      role: 'Exécution locale',
      icon: 'fas fa-city',
      color: 'purple',
      responsibilities: ['Mise en œuvre locale', 'Remontée d\'informations', 'Coordination territoriale']
    },
    {
      name: 'Société Civile',
      role: 'Participation et suivi',
      icon: 'fas fa-users',
      color: 'orange',
      responsibilities: ['Participation citoyenne', 'Suivi participatif', 'Feedback terrain']
    },
    {
      name: 'Secteur Privé',
      role: 'Partenariat et investissement',
      icon: 'fas fa-handshake',
      color: 'teal',
      responsibilities: ['Investissements privés', 'Partenariats PPP', 'Création d\'emplois']
    },
    {
      name: 'Organismes Internationaux',
      role: 'Appui technique et financier',
      icon: 'fas fa-globe',
      color: 'indigo',
      responsibilities: ['Financement', 'Assistance technique', 'Transfert d\'expertise']
    }
  ];

  const governanceProcesses = [
    {
      title: 'Planification',
      description: 'Élaboration et validation des plans d\'action',
      icon: 'fas fa-calendar-alt',
      frequency: 'Annuelle',
      participants: 'Conseil Régional, Ministères'
    },
    {
      title: 'Suivi',
      description: 'Collecte et analyse des données de performance',
      icon: 'fas fa-chart-line',
      frequency: 'Trimestrielle',
      participants: 'Équipe technique, Partenaires'
    },
    {
      title: 'Évaluation',
      description: 'Évaluation des résultats et impacts',
      icon: 'fas fa-search',
      frequency: 'Semestrielle',
      participants: 'Comité de pilotage'
    },
    {
      title: 'Ajustement',
      description: 'Révision et ajustement des stratégies',
      icon: 'fas fa-sync-alt',
      frequency: 'Selon besoins',
      participants: 'Toutes parties prenantes'
    }
  ];

  const consultations = [
    {
      date: 'Mars 2025',
      type: 'Consultation publique',
      theme: 'Révision mi-parcours du PDR',
      participants: 245,
      status: 'Terminée'
    },
    {
      date: 'Janvier 2025',
      type: 'Atelier sectoriel',
      theme: 'Agriculture et développement rural',
      participants: 85,
      status: 'Terminée'
    },
    {
      date: 'Novembre 2024',
      type: 'Forum régional',
      theme: 'Tourisme et patrimoine',
      participants: 156,
      status: 'Terminée'
    },
    {
      date: 'Septembre 2024',
      type: 'Consultation citoyenne',
      theme: 'Infrastructure et transport',
      participants: 312,
      status: 'Terminée'
    }
  ];

  const getColorClasses = (color) => {
    const colors = {
      blue: 'text-blue-600 bg-blue-100 border-blue-200',
      green: 'text-green-600 bg-green-100 border-green-200',
      purple: 'text-purple-600 bg-purple-100 border-purple-200',
      orange: 'text-orange-600 bg-orange-100 border-orange-200',
      teal: 'text-teal-600 bg-teal-100 border-teal-200',
      indigo: 'text-indigo-600 bg-indigo-100 border-indigo-200'
    };
    return colors[color] || 'text-gray-600 bg-gray-100 border-gray-200';
  };

  return (
    <div className="space-y-6">
      {/* En-tête de section */}
      <div className="section-header">
        <h2 className="text-3xl font-bold text-gray-800">Gouvernance et Parties Prenantes</h2>
        <p className="text-gray-600 mt-2">Structure organisationnelle et mécanismes de participation</p>
      </div>

      {/* Statistiques de gouvernance */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-blue-600 mb-2">6</div>
          <div className="text-gray-600">Types de Parties Prenantes</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-green-600 mb-2">12</div>
          <div className="text-gray-600">Consultations Publiques</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-purple-600 mb-2">798</div>
          <div className="text-gray-600">Participants Total</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-orange-600 mb-2">4</div>
          <div className="text-gray-600">Processus de Suivi</div>
        </div>
      </div>

      {/* Parties prenantes */}
      <div className="pdr-card rounded-lg p-6 pdr-shadow">
        <h3 className="text-xl font-bold text-gray-800 mb-6 flex items-center">
          <i className="fas fa-sitemap mr-2 pdr-accent"></i>
          Écosystème des Parties Prenantes
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {stakeholders.map((stakeholder, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center mr-3 ${getColorClasses(stakeholder.color)}`}>
                  <i className={stakeholder.icon}></i>
                </div>
                <div>
                  <h4 className="font-bold text-gray-800">{stakeholder.name}</h4>
                  <p className="text-sm text-gray-600">{stakeholder.role}</p>
                </div>
              </div>
              <div className="space-y-2">
                {stakeholder.responsibilities.map((responsibility, idx) => (
                  <div key={idx} className="flex items-center text-sm text-gray-700">
                    <i className="fas fa-check-circle text-green-500 mr-2 text-xs"></i>
                    {responsibility}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Processus de gouvernance */}
        <div className="pdr-card rounded-lg p-6 pdr-shadow">
          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-cogs mr-2 pdr-accent"></i>
            Processus de Gouvernance
          </h3>
          <div className="space-y-4">
            {governanceProcesses.map((process, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center mb-2">
                  <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center mr-3">
                    <i className={process.icon}></i>
                  </div>
                  <h4 className="font-bold text-gray-800">{process.title}</h4>
                </div>
                <p className="text-sm text-gray-600 mb-2">{process.description}</p>
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-gray-500">Fréquence:</span>
                    <span className="font-medium text-gray-700 ml-1">{process.frequency}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Participants:</span>
                    <span className="font-medium text-gray-700 ml-1">{process.participants}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Historique des consultations */}
        <div className="pdr-card rounded-lg p-6 pdr-shadow">
          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-comments mr-2 pdr-accent"></i>
            Consultations Récentes
          </h3>
          <div className="space-y-4">
            {consultations.map((consultation, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h4 className="font-bold text-gray-800">{consultation.type}</h4>
                    <p className="text-sm text-gray-600">{consultation.theme}</p>
                  </div>
                  <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                    {consultation.status}
                  </span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-500">{consultation.date}</span>
                  <span className="font-medium text-gray-700">
                    {consultation.participants} participants
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Mécanismes de participation */}
      <div className="pdr-card rounded-lg p-6 pdr-shadow">
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-vote-yea mr-2 pdr-accent"></i>
          Mécanismes de Participation Citoyenne
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center mx-auto mb-3">
              <i className="fas fa-users text-xl"></i>
            </div>
            <h4 className="font-bold text-gray-800 mb-2">Forums Publics</h4>
            <p className="text-sm text-gray-600">Débats ouverts sur les orientations stratégiques</p>
          </div>
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="w-12 h-12 bg-green-100 text-green-600 rounded-lg flex items-center justify-center mx-auto mb-3">
              <i className="fas fa-poll text-xl"></i>
            </div>
            <h4 className="font-bold text-gray-800 mb-2">Enquêtes</h4>
            <p className="text-sm text-gray-600">Sondages d'opinion et enquêtes de satisfaction</p>
          </div>
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-lg flex items-center justify-center mx-auto mb-3">
              <i className="fas fa-laptop text-xl"></i>
            </div>
            <h4 className="font-bold text-gray-800 mb-2">Plateforme Digitale</h4>
            <p className="text-sm text-gray-600">Participation en ligne et consultations virtuelles</p>
          </div>
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="w-12 h-12 bg-orange-100 text-orange-600 rounded-lg flex items-center justify-center mx-auto mb-3">
              <i className="fas fa-handshake text-xl"></i>
            </div>
            <h4 className="font-bold text-gray-800 mb-2">Partenariats</h4>
            <p className="text-sm text-gray-600">Collaboration avec les associations locales</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Governance;

