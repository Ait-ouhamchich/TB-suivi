import React from 'react';
import regionMap from '../assets/region_map.png';

const Map = () => {
  const provinces = [
    {
      name: 'Béni Mellal',
      population: '946,018',
      projects: 45,
      budget: '1.2B MAD',
      progress: 72,
      color: 'blue'
    },
    {
      name: 'Khénifra',
      population: '597,818',
      projects: 38,
      budget: '890M MAD',
      progress: 68,
      color: 'green'
    },
    {
      name: 'Khouribga',
      population: '499,144',
      projects: 32,
      budget: '750M MAD',
      progress: 75,
      color: 'purple'
    },
    {
      name: 'Azilal',
      population: '504,501',
      projects: 35,
      budget: '680M MAD',
      progress: 65,
      color: 'orange'
    },
    {
      name: 'Fquih Ben Salah',
      population: '338,221',
      projects: 25,
      budget: '480M MAD',
      progress: 70,
      color: 'teal'
    }
  ];

  const projectTypes = [
    { type: 'Infrastructure', count: 45, icon: 'fas fa-road', color: 'blue' },
    { type: 'Agriculture', count: 38, icon: 'fas fa-leaf', color: 'green' },
    { type: 'Éducation', count: 32, icon: 'fas fa-graduation-cap', color: 'purple' },
    { type: 'Santé', count: 28, icon: 'fas fa-hospital', color: 'red' },
    { type: 'Tourisme', count: 22, icon: 'fas fa-umbrella-beach', color: 'orange' },
    { type: 'Autres', count: 10, icon: 'fas fa-ellipsis-h', color: 'gray' }
  ];

  const getColorClasses = (color) => {
    const colors = {
      blue: 'text-blue-600 bg-blue-100 border-blue-200',
      green: 'text-green-600 bg-green-100 border-green-200',
      purple: 'text-purple-600 bg-purple-100 border-purple-200',
      orange: 'text-orange-600 bg-orange-100 border-orange-200',
      teal: 'text-teal-600 bg-teal-100 border-teal-200',
      red: 'text-red-600 bg-red-100 border-red-200',
      gray: 'text-gray-600 bg-gray-100 border-gray-200'
    };
    return colors[color] || 'text-gray-600 bg-gray-100 border-gray-200';
  };

  const getProgressColor = (progress) => {
    if (progress >= 75) return 'bg-green-500';
    if (progress >= 65) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="space-y-6">
      {/* En-tête de section */}
      <div className="section-header">
        <h2 className="text-3xl font-bold text-gray-800">Cartographie Régionale</h2>
        <p className="text-gray-600 mt-2">Répartition géographique des projets et indicateurs par province</p>
      </div>

      {/* Statistiques globales */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-blue-600 mb-2">5</div>
          <div className="text-gray-600">Provinces</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-green-600 mb-2">2.8M</div>
          <div className="text-gray-600">Population</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-purple-600 mb-2">175</div>
          <div className="text-gray-600">Projets Total</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-orange-600 mb-2">70%</div>
          <div className="text-gray-600">Avancement Moyen</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Carte de la région */}
        <div className="pdr-card rounded-lg p-6 pdr-shadow">
          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-map-marked-alt mr-2 pdr-accent"></i>
            Carte de la Région
          </h3>
          <div className="relative">
            <img 
              src={regionMap} 
              alt="Carte de la région Béni Mellal-Khénifra" 
              className="w-full h-auto rounded-lg border-2 pdr-border"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent rounded-lg"></div>
          </div>
          <p className="text-gray-600 mt-3 text-sm">
            Région de Béni Mellal-Khénifra avec ses 5 provinces et principales villes
          </p>
        </div>

        {/* Répartition des projets par type */}
        <div className="pdr-card rounded-lg p-6 pdr-shadow">
          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-chart-pie mr-2 pdr-accent"></i>
            Projets par Secteur
          </h3>
          <div className="space-y-3">
            {projectTypes.map((project, index) => (
              <div key={index} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                <div className="flex items-center">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center mr-3 ${getColorClasses(project.color)}`}>
                    <i className={`${project.icon} text-sm`}></i>
                  </div>
                  <span className="font-medium text-gray-800">{project.type}</span>
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold text-gray-800">{project.count}</div>
                  <div className="text-xs text-gray-500">projets</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Données par province */}
      <div className="pdr-card rounded-lg p-6 pdr-shadow">
        <h3 className="text-xl font-bold text-gray-800 mb-6 flex items-center">
          <i className="fas fa-table mr-2 pdr-accent"></i>
          Données par Province
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {provinces.map((province, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-lg font-bold text-gray-800">{province.name}</h4>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${getColorClasses(province.color)}`}>
                  <i className="fas fa-map-marker-alt text-sm"></i>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Population</span>
                  <span className="text-sm font-semibold text-gray-800">{province.population}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Projets</span>
                  <span className="text-sm font-semibold text-gray-800">{province.projects}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Budget</span>
                  <span className="text-sm font-semibold text-gray-800">{province.budget}</span>
                </div>

                {/* Barre de progression */}
                <div className="pt-2">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium text-gray-600">Avancement</span>
                    <span className="text-sm font-bold text-gray-800">{province.progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full transition-all duration-300 ${getProgressColor(province.progress)}`}
                      style={{ width: `${province.progress}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Légende et informations */}
      <div className="pdr-card rounded-lg p-6 pdr-shadow">
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-info-circle mr-2 pdr-accent"></i>
          Informations Géographiques
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600 mb-2">28,374 km²</div>
            <div className="text-gray-600">Superficie totale</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600 mb-2">99 hab/km²</div>
            <div className="text-gray-600">Densité moyenne</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600 mb-2">Béni Mellal</div>
            <div className="text-gray-600">Chef-lieu de région</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Map;

