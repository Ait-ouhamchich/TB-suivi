import React from 'react';
import dashboardMockup from '../assets/dashboard_mockup.png';
import ProgressChart from './charts/ProgressChart';
import BudgetChart from './charts/BudgetChart';
import { axesProgressData, budgetDistributionData, kpiData } from '../data/mockData';

const OverviewEnhanced = () => {
  const kpis = [
    { 
      title: 'Projets en cours', 
      value: kpiData.ongoingProjects, 
      icon: 'fas fa-project-diagram', 
      color: 'text-blue-600',
      trend: '+12',
      trendColor: 'text-green-600'
    },
    { 
      title: 'Budget exécuté', 
      value: `${Math.round((kpiData.executedBudget / kpiData.totalBudget) * 100)}%`, 
      icon: 'fas fa-coins', 
      color: 'text-green-600',
      trend: '+8%',
      trendColor: 'text-green-600'
    },
    { 
      title: 'Indicateurs suivis', 
      value: '26', 
      icon: 'fas fa-chart-line', 
      color: 'text-purple-600',
      trend: '+2',
      trendColor: 'text-green-600'
    },
    { 
      title: 'Emplois créés', 
      value: kpiData.jobsCreated.toLocaleString(), 
      icon: 'fas fa-users', 
      color: 'text-orange-600',
      trend: '+1,250',
      trendColor: 'text-green-600'
    }
  ];

  return (
    <div className="space-y-6">
      {/* En-tête de section */}
      <div className="section-header">
        <h2 className="text-3xl font-bold text-gray-800">Vue d'ensemble du PDR</h2>
        <p className="text-gray-600 mt-2">Synthèse des indicateurs clés de performance et état d'avancement global</p>
      </div>

      {/* KPIs principaux */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpis.map((kpi, index) => (
          <div key={index} className="pdr-card rounded-lg p-6 text-center pdr-shadow hover:shadow-lg transition-shadow">
            <div className={`text-4xl mb-3 ${kpi.color}`}>
              <i className={kpi.icon}></i>
            </div>
            <div className="text-3xl font-bold text-gray-800 mb-2">{kpi.value}</div>
            <div className="text-gray-600 font-medium mb-2">{kpi.title}</div>
            <div className={`text-sm font-medium ${kpi.trendColor}`}>
              <i className="fas fa-arrow-up mr-1"></i>
              {kpi.trend}
            </div>
          </div>
        ))}
      </div>

      {/* Graphiques principaux */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Avancement par axes */}
        <div className="pdr-card rounded-lg p-6 pdr-shadow">
          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-chart-bar mr-2 pdr-accent"></i>
            Avancement par Axe Stratégique
          </h3>
          <ProgressChart 
            data={axesProgressData} 
            title="Progression des Axes Stratégiques (%)"
          />
        </div>

        {/* Répartition budgétaire */}
        <div className="pdr-card rounded-lg p-6 pdr-shadow">
          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-chart-pie mr-2 pdr-accent"></i>
            Répartition Budgétaire
          </h3>
          <BudgetChart 
            data={budgetDistributionData} 
            title="Budget par Secteur (M MAD)"
          />
        </div>
      </div>

      {/* Métriques détaillées */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="pdr-card rounded-lg p-6 pdr-shadow">
          <h4 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-target mr-2 text-blue-600"></i>
            Objectifs 2025
          </h4>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Projets à finaliser</span>
              <span className="font-bold text-gray-800">45</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Budget à exécuter</span>
              <span className="font-bold text-gray-800">1.28B MAD</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Emplois à créer</span>
              <span className="font-bold text-gray-800">2,550</span>
            </div>
          </div>
        </div>

        <div className="pdr-card rounded-lg p-6 pdr-shadow">
          <h4 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-clock mr-2 text-green-600"></i>
            Calendrier
          </h4>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Phase actuelle</span>
              <span className="font-bold text-gray-800">Consolidation</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Durée restante</span>
              <span className="font-bold text-gray-800">2.5 ans</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Prochaine évaluation</span>
              <span className="font-bold text-gray-800">Juin 2025</span>
            </div>
          </div>
        </div>

        <div className="pdr-card rounded-lg p-6 pdr-shadow">
          <h4 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-users mr-2 text-purple-600"></i>
            Impact Social
          </h4>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Bénéficiaires directs</span>
              <span className="font-bold text-gray-800">2.8M</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Communes couvertes</span>
              <span className="font-bold text-gray-800">195</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Taux de satisfaction</span>
              <span className="font-bold text-gray-800">87%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Aperçu du tableau de bord */}
      <div className="pdr-card rounded-lg p-6 pdr-shadow">
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-desktop mr-2 pdr-accent"></i>
          Interface du Tableau de Bord
        </h3>
        <div className="relative">
          <img 
            src={dashboardMockup} 
            alt="Aperçu du tableau de bord" 
            className="w-full h-auto rounded-lg border-2 pdr-border"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-lg"></div>
        </div>
        <p className="text-gray-600 mt-3 text-sm">
          Interface intuitive avec navigation claire et visualisations interactives pour un suivi en temps réel
        </p>
      </div>

      {/* Alertes et notifications */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="pdr-card rounded-lg p-6 pdr-shadow border-l-4 border-yellow-500">
          <h4 className="text-lg font-bold text-gray-800 mb-3 flex items-center">
            <i className="fas fa-exclamation-triangle mr-2 text-yellow-500"></i>
            Points d'Attention
          </h4>
          <ul className="space-y-2 text-sm">
            <li className="flex items-center text-gray-700">
              <i className="fas fa-circle text-yellow-500 mr-2 text-xs"></i>
              Retard sur 3 projets d'infrastructure
            </li>
            <li className="flex items-center text-gray-700">
              <i className="fas fa-circle text-yellow-500 mr-2 text-xs"></i>
              Budget tourisme sous-exécuté (58%)
            </li>
            <li className="flex items-center text-gray-700">
              <i className="fas fa-circle text-yellow-500 mr-2 text-xs"></i>
              Indicateur sport en dessous de la cible
            </li>
          </ul>
        </div>

        <div className="pdr-card rounded-lg p-6 pdr-shadow border-l-4 border-green-500">
          <h4 className="text-lg font-bold text-gray-800 mb-3 flex items-center">
            <i className="fas fa-check-circle mr-2 text-green-500"></i>
            Réussites Notables
          </h4>
          <ul className="space-y-2 text-sm">
            <li className="flex items-center text-gray-700">
              <i className="fas fa-circle text-green-500 mr-2 text-xs"></i>
              Agriculture: 82% d'avancement
            </li>
            <li className="flex items-center text-gray-700">
              <i className="fas fa-circle text-green-500 mr-2 text-xs"></i>
              Éducation: objectifs 2025 atteints
            </li>
            <li className="flex items-center text-gray-700">
              <i className="fas fa-circle text-green-500 mr-2 text-xs"></i>
              12,450 emplois créés (+25% vs objectif)
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default OverviewEnhanced;

