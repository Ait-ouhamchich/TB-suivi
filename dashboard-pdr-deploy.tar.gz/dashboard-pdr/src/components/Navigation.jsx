import React, { useState } from 'react';

const Navigation = ({ activeSection, setActiveSection }) => {
  const sections = [
    { id: 'overview', name: 'Vue d\'ensemble', icon: 'fas fa-tachometer-alt' },
    { id: 'axes', name: 'Axes Stratégiques', icon: 'fas fa-sitemap' },
    { id: 'indicators', name: 'Indicateurs', icon: 'fas fa-chart-bar' },
    { id: 'map', name: 'Cartographie', icon: 'fas fa-map-marked-alt' },
    { id: 'governance', name: 'Gouvernance', icon: 'fas fa-users-cog' },
    { id: 'reports', name: 'Rapports', icon: 'fas fa-file-alt' }
  ];

  return (
    <nav className="bg-white shadow-md border-b">
      <div className="container mx-auto px-6">
        <div className="flex space-x-8 overflow-x-auto">
          {sections.map((section) => (
            <button
              key={section.id}
              onClick={() => setActiveSection(section.id)}
              className={`flex items-center space-x-2 py-4 px-2 border-b-2 transition-colors whitespace-nowrap ${
                activeSection === section.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-600 hover:text-blue-600 hover:border-blue-300'
              }`}
            >
              <i className={section.icon}></i>
              <span className="font-medium">{section.name}</span>
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
};

export default Navigation;

