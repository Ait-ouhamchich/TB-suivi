import React from 'react';

const DashboardSelector = ({ currentDashboard, setCurrentDashboard }) => {
  return (
    <div className="bg-white shadow-sm border-b border-gray-200">
      <div className="container mx-auto px-6">
        <div className="flex items-center justify-center py-4">
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setCurrentDashboard('PDR')}
              className={`px-6 py-2 rounded-md font-medium transition-all duration-200 ${
                currentDashboard === 'PDR'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-gray-600 hover:text-gray-800 hover:bg-gray-200'
              }`}
            >
              <i className="fas fa-chart-line mr-2"></i>
              Tableau de Bord PDR
            </button>
            <button
              onClick={() => setCurrentDashboard('SRAT')}
              className={`px-6 py-2 rounded-md font-medium transition-all duration-200 ${
                currentDashboard === 'SRAT'
                  ? 'bg-teal-600 text-white shadow-md'
                  : 'text-gray-600 hover:text-gray-800 hover:bg-gray-200'
              }`}
            >
              <i className="fas fa-map-marked-alt mr-2"></i>
              Tableau de Bord SRAT
            </button>
          </div>
        </div>
        
        {/* Description du tableau de bord actuel */}
        <div className="pb-4">
          <div className="text-center">
            {currentDashboard === 'PDR' ? (
              <p className="text-gray-600 text-sm">
                <i className="fas fa-info-circle mr-1"></i>
                Programme de Développement Régional - Suivi des projets et indicateurs de développement économique et social
              </p>
            ) : (
              <p className="text-gray-600 text-sm">
                <i className="fas fa-info-circle mr-1"></i>
                Schéma Régional d'Aménagement du Territoire - Suivi de l'aménagement territorial et du développement durable
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardSelector;

