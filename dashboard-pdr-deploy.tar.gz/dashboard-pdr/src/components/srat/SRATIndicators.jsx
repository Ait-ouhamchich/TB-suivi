import React from 'react';
import IndicatorChart from '../charts/IndicatorChart';

const SRATIndicators = () => {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Indicateurs d'Aménagement du Territoire</h1>
        <p className="text-gray-600">Suivi détaillé des indicateurs SMART par domaine d'aménagement</p>
      </div>

      {/* KPIs principaux */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <div className="text-3xl font-bold text-blue-600 mb-2">18</div>
          <div className="text-gray-600 font-medium">Indicateurs Total</div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <div className="text-3xl font-bold text-green-600 mb-2">12</div>
          <div className="text-gray-600 font-medium">En Bonne Voie</div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <div className="text-3xl font-bold text-yellow-600 mb-2">4</div>
          <div className="text-gray-600 font-medium">Objectifs Atteints</div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <div className="text-3xl font-bold text-red-600 mb-2">2</div>
          <div className="text-gray-600 font-medium">Nécessitent Attention</div>
        </div>
      </div>

      {/* Graphique d'évolution */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-chart-line text-teal-500 mr-2"></i>
          Évolution des Indicateurs Clés
        </h3>
        <IndicatorChart 
          data={{
            labels: ['2021', '2022', '2023', '2024', '2025 (proj)', '2026 (proj)', '2027 (obj)'],
            datasets: [
              {
                label: 'Taux d\'Équipement Rural (%)',
                data: [45, 52, 58, 65, 70, 75, 80],
                borderColor: 'rgba(72, 201, 176, 1)',
                backgroundColor: 'rgba(72, 201, 176, 0.1)',
                tension: 0.4
              },
              {
                label: 'Objectif',
                data: [45, 50, 55, 60, 65, 70, 80],
                borderColor: 'rgba(72, 201, 176, 0.5)',
                backgroundColor: 'transparent',
                borderDash: [5, 5],
                tension: 0.4
              }
            ]
          }}
          title="Taux d'Équipement Rural (%)"
        />
      </div>

      {/* Indicateurs par domaine */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-road text-blue-500 mr-2"></i>
            Infrastructures et Connectivité
          </h3>
          <div className="space-y-4">
            <div className="border-l-4 border-blue-500 pl-4">
              <div className="flex justify-between items-center mb-2">
                <span className="font-medium text-gray-800">Taux de Désenclavement</span>
                <span className="text-blue-600 font-bold">78%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-500 h-2 rounded-full" style={{width: '78%'}}></div>
              </div>
              <div className="text-sm text-gray-600 mt-1">Objectif 2045: 95%</div>
            </div>

            <div className="border-l-4 border-green-500 pl-4">
              <div className="flex justify-between items-center mb-2">
                <span className="font-medium text-gray-800">Couverture Réseau Routier</span>
                <span className="text-green-600 font-bold">85%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-green-500 h-2 rounded-full" style={{width: '85%'}}></div>
              </div>
              <div className="text-sm text-gray-600 mt-1">Objectif 2045: 90%</div>
            </div>

            <div className="border-l-4 border-yellow-500 pl-4">
              <div className="flex justify-between items-center mb-2">
                <span className="font-medium text-gray-800">Accès Internet Haut Débit</span>
                <span className="text-yellow-600 font-bold">62%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-yellow-500 h-2 rounded-full" style={{width: '62%'}}></div>
              </div>
              <div className="text-sm text-gray-600 mt-1">Objectif 2045: 85%</div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-water text-blue-600 mr-2"></i>
            Ressources et Environnement
          </h3>
          <div className="space-y-4">
            <div className="border-l-4 border-blue-600 pl-4">
              <div className="flex justify-between items-center mb-2">
                <span className="font-medium text-gray-800">Accès à l'Eau Potable</span>
                <span className="text-blue-600 font-bold">92%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-600 h-2 rounded-full" style={{width: '92%'}}></div>
              </div>
              <div className="text-sm text-gray-600 mt-1">Objectif 2045: 98%</div>
            </div>

            <div className="border-l-4 border-green-600 pl-4">
              <div className="flex justify-between items-center mb-2">
                <span className="font-medium text-gray-800">Traitement des Eaux Usées</span>
                <span className="text-green-600 font-bold">68%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-green-600 h-2 rounded-full" style={{width: '68%'}}></div>
              </div>
              <div className="text-sm text-gray-600 mt-1">Objectif 2045: 85%</div>
            </div>

            <div className="border-l-4 border-red-500 pl-4">
              <div className="flex justify-between items-center mb-2">
                <span className="font-medium text-gray-800">Couverture Forestière</span>
                <span className="text-red-600 font-bold">45%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-red-500 h-2 rounded-full" style={{width: '45%'}}></div>
              </div>
              <div className="text-sm text-gray-600 mt-1">Objectif 2045: 55% (Attention requise)</div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-city text-purple-500 mr-2"></i>
            Développement Urbain
          </h3>
          <div className="space-y-4">
            <div className="border-l-4 border-purple-500 pl-4">
              <div className="flex justify-between items-center mb-2">
                <span className="font-medium text-gray-800">Taux d'Urbanisation</span>
                <span className="text-purple-600 font-bold">58%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-purple-500 h-2 rounded-full" style={{width: '58%'}}></div>
              </div>
              <div className="text-sm text-gray-600 mt-1">Objectif 2045: 65%</div>
            </div>

            <div className="border-l-4 border-indigo-500 pl-4">
              <div className="flex justify-between items-center mb-2">
                <span className="font-medium text-gray-800">Équipements Publics</span>
                <span className="text-indigo-600 font-bold">72%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-indigo-500 h-2 rounded-full" style={{width: '72%'}}></div>
              </div>
              <div className="text-sm text-gray-600 mt-1">Objectif 2045: 85%</div>
            </div>

            <div className="border-l-4 border-pink-500 pl-4">
              <div className="flex justify-between items-center mb-2">
                <span className="font-medium text-gray-800">Espaces Verts Urbains</span>
                <span className="text-pink-600 font-bold">35%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-pink-500 h-2 rounded-full" style={{width: '35%'}}></div>
              </div>
              <div className="text-sm text-gray-600 mt-1">Objectif 2045: 50%</div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-chart-pie text-orange-500 mr-2"></i>
            Développement Économique
          </h3>
          <div className="space-y-4">
            <div className="border-l-4 border-orange-500 pl-4">
              <div className="flex justify-between items-center mb-2">
                <span className="font-medium text-gray-800">PIB Régional (Croissance)</span>
                <span className="text-orange-600 font-bold">4.2%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-orange-500 h-2 rounded-full" style={{width: '84%'}}></div>
              </div>
              <div className="text-sm text-gray-600 mt-1">Objectif 2045: 5%</div>
            </div>

            <div className="border-l-4 border-teal-500 pl-4">
              <div className="flex justify-between items-center mb-2">
                <span className="font-medium text-gray-800">Taux d'Emploi</span>
                <span className="text-teal-600 font-bold">68%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-teal-500 h-2 rounded-full" style={{width: '68%'}}></div>
              </div>
              <div className="text-sm text-gray-600 mt-1">Objectif 2045: 75%</div>
            </div>

            <div className="border-l-4 border-cyan-500 pl-4">
              <div className="flex justify-between items-center mb-2">
                <span className="font-medium text-gray-800">Investissements Privés</span>
                <span className="text-cyan-600 font-bold">82%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-cyan-500 h-2 rounded-full" style={{width: '82%'}}></div>
              </div>
              <div className="text-sm text-gray-600 mt-1">Objectif 2045: 90%</div>
            </div>
          </div>
        </div>
      </div>

      {/* Tableau de bord visuel */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-chart-area text-teal-500 mr-2"></i>
          Tableau de Bord Visuel SRAT
        </h3>
        <div className="bg-gradient-to-r from-teal-50 to-blue-50 p-6 rounded-lg">
          <img 
            src="/home/ubuntu/indicators_visualization.png" 
            alt="Visualisation des indicateurs SRAT" 
            className="w-full h-auto rounded-lg shadow-sm"
          />
        </div>
        <p className="text-gray-600 text-sm mt-4">
          Interface intuitive avec visualisations interactives pour un suivi en temps réel des indicateurs d'aménagement du territoire
        </p>
      </div>
    </div>
  );
};

export default SRATIndicators;

