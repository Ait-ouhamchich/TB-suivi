import React, { useState } from 'react';

const SRATNavigation = ({ activeSection, setActiveSection }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const menuItems = [
    { id: 'overview', label: 'Vue d\'ensemble', icon: 'fas fa-tachometer-alt' },
    { id: 'strategic-axes', label: 'Orientations Stratégiques', icon: 'fas fa-compass' },
    { id: 'indicators', label: 'Indicateurs', icon: 'fas fa-chart-line' },
    { id: 'spaces', label: 'Espaces Projets', icon: 'fas fa-map-marked-alt' },
    { id: 'governance', label: 'Gouvernance', icon: 'fas fa-users-cog' },
    { id: 'reports', label: 'Rapports', icon: 'fas fa-file-alt' }
  ];

  return (
    <nav className="bg-teal-600 text-white shadow-lg">
      <div className="container mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <i className="fas fa-map-marked-alt text-2xl mr-3"></i>
            <span className="font-bold text-lg">SRAT Béni Mellal-Khénifra</span>
          </div>
          
          {/* Menu desktop */}
          <div className="hidden md:flex space-x-1">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveSection(item.id)}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
                  activeSection === item.id
                    ? 'bg-teal-700 text-white'
                    : 'text-teal-100 hover:bg-teal-500 hover:text-white'
                }`}
              >
                <i className={`${item.icon} mr-2`}></i>
                {item.label}
              </button>
            ))}
          </div>

          {/* Menu mobile */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-teal-100 hover:text-white focus:outline-none focus:text-white"
            >
              <i className={`fas ${isMenuOpen ? 'fa-times' : 'fa-bars'} text-xl`}></i>
            </button>
          </div>
        </div>

        {/* Menu mobile dropdown */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {menuItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveSection(item.id);
                    setIsMenuOpen(false);
                  }}
                  className={`block w-full text-left px-3 py-2 rounded-md text-base font-medium transition-colors duration-200 ${
                    activeSection === item.id
                      ? 'bg-teal-700 text-white'
                      : 'text-teal-100 hover:bg-teal-500 hover:text-white'
                  }`}
                >
                  <i className={`${item.icon} mr-2`}></i>
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default SRATNavigation;

