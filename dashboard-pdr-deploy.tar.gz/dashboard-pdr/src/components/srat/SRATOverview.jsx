import React from 'react';
import ProgressChart from '../charts/ProgressChart';
import BudgetChart from '../charts/BudgetChart';
import { sratOverviewData } from '../../data/sratMockData';

const SRATOverview = () => {
  const { kpis, avancementEspaces, repartitionInvestissements } = sratOverviewData;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Vue d'ensemble du SRAT</h1>
        <p className="text-gray-600">Synthèse des indicateurs clés d'aménagement du territoire et état d'avancement global</p>
      </div>

      {/* KPIs principaux */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-500">
          <div className="flex items-center justify-center mb-4">
            <i className="fas fa-map-marked-alt text-3xl text-blue-500"></i>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-gray-800">{kpis.espacesProjects}</div>
            <div className="text-gray-600 font-medium">Espaces Projets</div>
            <div className="text-green-500 text-sm font-medium mt-1">
              <i className="fas fa-arrow-up mr-1"></i>+1
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-green-500">
          <div className="flex items-center justify-center mb-4">
            <i className="fas fa-percentage text-3xl text-green-500"></i>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-gray-800">{kpis.avancementGlobal}%</div>
            <div className="text-gray-600 font-medium">Avancement Global</div>
            <div className="text-green-500 text-sm font-medium mt-1">
              <i className="fas fa-arrow-up mr-1"></i>+5%
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-500">
          <div className="flex items-center justify-center mb-4">
            <i className="fas fa-chart-line text-3xl text-purple-500"></i>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-gray-800">{kpis.indicateursSuivis}</div>
            <div className="text-gray-600 font-medium">Indicateurs Suivis</div>
            <div className="text-green-500 text-sm font-medium mt-1">
              <i className="fas fa-arrow-up mr-1"></i>+3
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-orange-500">
          <div className="flex items-center justify-center mb-4">
            <i className="fas fa-users text-3xl text-orange-500"></i>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-gray-800">{kpis.populationCouverte}M</div>
            <div className="text-gray-600 font-medium">Population Couverte</div>
            <div className="text-green-500 text-sm font-medium mt-1">
              <i className="fas fa-arrow-up mr-1"></i>+2.5%
            </div>
          </div>
        </div>
      </div>

      {/* Graphiques */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-chart-bar text-teal-500 mr-2"></i>
            Avancement par Espace Projet
          </h3>
          <ProgressChart 
            data={avancementEspaces}
            title="Progression des Espaces Projets (%)"
          />
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-chart-pie text-teal-500 mr-2"></i>
            Répartition des Investissements
          </h3>
          <BudgetChart 
            data={repartitionInvestissements}
            title="Investissements par Secteur (%)"
          />
        </div>
      </div>

      {/* Sections d'information */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h4 className="text-lg font-bold text-gray-800 mb-4">Objectifs 2045</h4>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Espaces à valoriser</span>
              <span className="font-bold">4</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Investissement total</span>
              <span className="font-bold">2.8B MAD</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Emplois à créer</span>
              <span className="font-bold">15,000</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h4 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-calendar-alt text-green-500 mr-2"></i>
            Calendrier
          </h4>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Phase actuelle</span>
              <span className="font-bold">Mise en œuvre</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Durée restante</span>
              <span className="font-bold">20 ans</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Prochaine évaluation</span>
              <span className="font-bold">Déc 2025</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h4 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-users text-purple-500 mr-2"></i>
            Impact Territorial
          </h4>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Communes concernées</span>
              <span className="font-bold">195</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Provinces</span>
              <span className="font-bold">5</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Taux de couverture</span>
              <span className="font-bold">100%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Section Vision SRAT */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-eye text-teal-500 mr-2"></i>
          Vision du SRAT 2021-2045
        </h3>
        <div className="bg-gradient-to-r from-teal-50 to-blue-50 p-6 rounded-lg">
          <p className="text-gray-700 leading-relaxed">
            Le Schéma Régional d'Aménagement du Territoire de Béni Mellal-Khénifra vise à positionner la région comme un territoire d'avenir, 
            valorisant ses potentialités naturelles et humaines pour un développement durable et intégré. L'objectif est de créer un équilibre 
            territorial harmonieux entre les espaces urbains et ruraux, tout en renforçant la compétitivité économique et l'attractivité de la région.
          </p>
        </div>
        
        <div className="mt-6">
          <h4 className="font-bold text-gray-800 mb-3">Points d'Attention</h4>
          <ul className="space-y-2 text-gray-600">
            <li className="flex items-start">
              <i className="fas fa-exclamation-triangle text-yellow-500 mr-2 mt-1"></i>
              Renforcement nécessaire de l'armature urbaine
            </li>
            <li className="flex items-start">
              <i className="fas fa-exclamation-triangle text-yellow-500 mr-2 mt-1"></i>
              Développement humain insuffisant dans certaines zones
            </li>
            <li className="flex items-start">
              <i className="fas fa-exclamation-triangle text-yellow-500 mr-2 mt-1"></i>
              Base économique à diversifier et renforcer
            </li>
          </ul>
        </div>

        <div className="mt-6">
          <h4 className="font-bold text-gray-800 mb-3">Réussites Notables</h4>
          <ul className="space-y-2 text-gray-600">
            <li className="flex items-start">
              <i className="fas fa-check-circle text-green-500 mr-2 mt-1"></i>
              Capital matériel et immatériel important valorisé
            </li>
            <li className="flex items-start">
              <i className="fas fa-check-circle text-green-500 mr-2 mt-1"></i>
              Perspectives prometteuses de construction régionale
            </li>
            <li className="flex items-start">
              <i className="fas fa-check-circle text-green-500 mr-2 mt-1"></i>
              Positionnement stratégique défini pour 2045
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default SRATOverview;

