import React from 'react';
import ProgressChart from '../charts/ProgressChart';
import { sratStrategicAxesData } from '../../data/sratMockData';

const SRATStrategicAxes = () => {
  const { kpis, avancementOrientations, orientations, espacesProjects } = sratStrategicAxesData;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Orientations Stratégiques du SRAT</h1>
        <p className="text-gray-600">Suivi détaillé de l'avancement par orientation stratégique d'aménagement du territoire</p>
      </div>

      {/* KPIs principaux */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <div className="text-3xl font-bold text-blue-600 mb-2">{kpis.orientationsStrategiques}</div>
          <div className="text-gray-600 font-medium">Orientations Stratégiques</div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <div className="text-3xl font-bold text-green-600 mb-2">{kpis.projetsStructurants}</div>
          <div className="text-gray-600 font-medium">Projets Structurants</div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <div className="text-3xl font-bold text-purple-600 mb-2">{kpis.budgetTotal}B</div>
          <div className="text-gray-600 font-medium">Budget Total (MAD)</div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <div className="text-3xl font-bold text-orange-600 mb-2">{kpis.avancementMoyen}%</div>
          <div className="text-gray-600 font-medium">Avancement Moyen</div>
        </div>
      </div>

      {/* Graphique d'avancement */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-chart-bar text-teal-500 mr-2"></i>
          Avancement par Orientation
        </h3>
        <ProgressChart 
          data={avancementOrientations}
          title="Progression des Orientations Stratégiques (%)"
        />
      </div>

      {/* Détail des orientations stratégiques */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {orientations.slice(0, 4).map((orientation) => (
          <div key={orientation.id} className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
              <i className={`${orientation.icon} text-${orientation.color}-500 mr-2`}></i>
              {orientation.id}. {orientation.titre}
            </h3>
            <div className="space-y-4">
              <div className={`bg-${orientation.color}-50 p-4 rounded-lg`}>
                <h4 className="font-semibold text-gray-800 mb-2">Objectifs</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  {orientation.objectifs.map((objectif, index) => (
                    <li key={index}>• {objectif}</li>
                  ))}
                </ul>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Avancement</span>
                <div className="flex items-center">
                  <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                    <div className={`bg-${orientation.color}-500 h-2 rounded-full`} style={{width: `${orientation.avancement}%`}}></div>
                  </div>
                  <span className="text-sm font-bold">{orientation.avancement}%</span>
                </div>
              </div>
              <div className="text-sm text-gray-600">
                <strong>Projets clés :</strong> {orientation.projetsClés}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Cinquième orientation */}
      {orientations.length > 4 && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <i className={`${orientations[4].icon} text-${orientations[4].color}-500 mr-2`}></i>
            {orientations[4].id}. {orientations[4].titre}
          </h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className={`bg-${orientations[4].color}-50 p-4 rounded-lg`}>
              <h4 className="font-semibold text-gray-800 mb-2">Objectifs</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                {orientations[4].objectifs.map((objectif, index) => (
                  <li key={index}>• {objectif}</li>
                ))}
              </ul>
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Avancement</span>
                <div className="flex items-center">
                  <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                    <div className={`bg-${orientations[4].color}-500 h-2 rounded-full`} style={{width: `${orientations[4].avancement}%`}}></div>
                  </div>
                  <span className="text-sm font-bold">{orientations[4].avancement}%</span>
                </div>
              </div>
              <div className="text-sm text-gray-600">
                <strong>Projets clés :</strong> {orientations[4].projetsClés}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Espaces projets */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-map-marked-alt text-teal-500 mr-2"></i>
          Espaces Projets Structurants
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {espacesProjects.map((espace, index) => (
            <div key={index} className={`bg-gradient-to-br from-${espace.color}-50 to-${espace.color}-100 p-4 rounded-lg text-center`}>
              <h4 className={`font-bold text-${espace.color}-800 mb-2`}>{espace.nom}</h4>
              <p className={`text-sm text-${espace.color}-600 mb-2`}>{espace.description}</p>
              <div className={`text-2xl font-bold text-${espace.color}-800`}>{espace.avancement}%</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SRATStrategicAxes;

