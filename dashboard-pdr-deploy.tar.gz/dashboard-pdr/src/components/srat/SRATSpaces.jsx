import React from 'react';

const SRATSpaces = () => {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Espaces Projets du SRAT</h1>
        <p className="text-gray-600">Répartition géographique des projets et indicateurs par espace territorial</p>
      </div>

      {/* KPIs principaux */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <div className="text-3xl font-bold text-blue-600 mb-2">4</div>
          <div className="text-gray-600 font-medium">Espaces Projets</div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <div className="text-3xl font-bold text-green-600 mb-2">2.8M</div>
          <div className="text-gray-600 font-medium">Population</div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <div className="text-3xl font-bold text-purple-600 mb-2">85</div>
          <div className="text-gray-600 font-medium">Projets Total</div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <div className="text-3xl font-bold text-orange-600 mb-2">72%</div>
          <div className="text-gray-600 font-medium">Avancement Moyen</div>
        </div>
      </div>

      {/* Carte de la région */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-map text-teal-500 mr-2"></i>
          Carte des Espaces Projets
        </h3>
        <div className="bg-gradient-to-r from-teal-50 to-blue-50 p-6 rounded-lg">
          <img 
            src="/home/ubuntu/region_map.png" 
            alt="Carte de la région Béni Mellal-Khénifra" 
            className="w-full h-auto rounded-lg shadow-sm"
          />
        </div>
        <p className="text-gray-600 text-sm mt-4">
          Répartition géographique des quatre espaces projets structurants du SRAT
        </p>
      </div>

      {/* Détail des espaces projets */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-seedling text-blue-500 mr-2"></i>
            Espace Projet DIR
          </h3>
          <div className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-800 mb-2">Développement Intégré Rural</h4>
              <p className="text-sm text-gray-600 mb-3">
                Espace dédié au développement rural intégré, valorisant les potentialités agricoles et pastorales.
              </p>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Population:</span>
                  <span className="font-bold ml-2">650K</span>
                </div>
                <div>
                  <span className="text-gray-600">Superficie:</span>
                  <span className="font-bold ml-2">8,500 km²</span>
                </div>
                <div>
                  <span className="text-gray-600">Communes:</span>
                  <span className="font-bold ml-2">45</span>
                </div>
                <div>
                  <span className="text-gray-600">Projets:</span>
                  <span className="font-bold ml-2">18</span>
                </div>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Avancement</span>
              <div className="flex items-center">
                <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                  <div className="bg-blue-500 h-2 rounded-full" style={{width: '78%'}}></div>
                </div>
                <span className="text-sm font-bold">78%</span>
              </div>
            </div>
            <div className="text-sm text-gray-600">
              <strong>Projets clés :</strong> Modernisation agricole, centres ruraux, routes de désenclavement
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-mountain text-green-500 mr-2"></i>
            Espace Projet PLATEAU
          </h3>
          <div className="space-y-4">
            <div className="bg-green-50 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-800 mb-2">Plateau et Montagnes</h4>
              <p className="text-sm text-gray-600 mb-3">
                Espace montagnard et de plateau, axé sur le tourisme écologique et la préservation environnementale.
              </p>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Population:</span>
                  <span className="font-bold ml-2">420K</span>
                </div>
                <div>
                  <span className="text-gray-600">Superficie:</span>
                  <span className="font-bold ml-2">6,200 km²</span>
                </div>
                <div>
                  <span className="text-gray-600">Communes:</span>
                  <span className="font-bold ml-2">38</span>
                </div>
                <div>
                  <span className="text-gray-600">Projets:</span>
                  <span className="font-bold ml-2">22</span>
                </div>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Avancement</span>
              <div className="flex items-center">
                <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{width: '85%'}}></div>
                </div>
                <span className="text-sm font-bold">85%</span>
              </div>
            </div>
            <div className="text-sm text-gray-600">
              <strong>Projets clés :</strong> Circuits touristiques, aires protégées, infrastructures écotouristiques
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-wheat text-yellow-500 mr-2"></i>
            Espace Projet PLAINE
          </h3>
          <div className="space-y-4">
            <div className="bg-yellow-50 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-800 mb-2">Plaine Agricole</h4>
              <p className="text-sm text-gray-600 mb-3">
                Espace de plaine à vocation agricole intensive, pôle de production et d'agro-industrie.
              </p>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Population:</span>
                  <span className="font-bold ml-2">1.2M</span>
                </div>
                <div>
                  <span className="text-gray-600">Superficie:</span>
                  <span className="font-bold ml-2">4,800 km²</span>
                </div>
                <div>
                  <span className="text-gray-600">Communes:</span>
                  <span className="font-bold ml-2">68</span>
                </div>
                <div>
                  <span className="text-gray-600">Projets:</span>
                  <span className="font-bold ml-2">28</span>
                </div>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Avancement</span>
              <div className="flex items-center">
                <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                  <div className="bg-yellow-500 h-2 rounded-full" style={{width: '68%'}}></div>
                </div>
                <span className="text-sm font-bold">68%</span>
              </div>
            </div>
            <div className="text-sm text-gray-600">
              <strong>Projets clés :</strong> Zones industrielles, irrigation moderne, centres logistiques
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-tree text-green-600 mr-2"></i>
            Espace Projet MONTAGNE
          </h3>
          <div className="space-y-4">
            <div className="bg-green-50 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-800 mb-2">Espace Montagnard</h4>
              <p className="text-sm text-gray-600 mb-3">
                Espace de haute montagne, axé sur la conservation, le tourisme de montagne et l'économie forestière.
              </p>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Population:</span>
                  <span className="font-bold ml-2">530K</span>
                </div>
                <div>
                  <span className="text-gray-600">Superficie:</span>
                  <span className="font-bold ml-2">9,100 km²</span>
                </div>
                <div>
                  <span className="text-gray-600">Communes:</span>
                  <span className="font-bold ml-2">44</span>
                </div>
                <div>
                  <span className="text-gray-600">Projets:</span>
                  <span className="font-bold ml-2">17</span>
                </div>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Avancement</span>
              <div className="flex items-center">
                <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                  <div className="bg-green-600 h-2 rounded-full" style={{width: '65%'}}></div>
                </div>
                <span className="text-sm font-bold">65%</span>
              </div>
            </div>
            <div className="text-sm text-gray-600">
              <strong>Projets clés :</strong> Stations de montagne, reboisement, gestion des bassins versants
            </div>
          </div>
        </div>
      </div>

      {/* Projets transversaux */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-network-wired text-teal-500 mr-2"></i>
          Projets Structurants Transversaux
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg">
            <h4 className="font-bold text-blue-800 mb-2 flex items-center">
              <i className="fas fa-road mr-2"></i>
              Infrastructures de Transport
            </h4>
            <p className="text-sm text-blue-600 mb-3">
              Réseau routier régional, liaisons inter-espaces, désenclavement rural
            </p>
            <div className="text-2xl font-bold text-blue-800">82%</div>
            <div className="text-sm text-blue-600">15 projets en cours</div>
          </div>

          <div className="bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-lg">
            <h4 className="font-bold text-green-800 mb-2 flex items-center">
              <i className="fas fa-wifi mr-2"></i>
              Connectivité Numérique
            </h4>
            <p className="text-sm text-green-600 mb-3">
              Couverture internet, services numériques, e-gouvernance
            </p>
            <div className="text-2xl font-bold text-green-800">75%</div>
            <div className="text-sm text-green-600">8 projets en cours</div>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-4 rounded-lg">
            <h4 className="font-bold text-purple-800 mb-2 flex items-center">
              <i className="fas fa-graduation-cap mr-2"></i>
              Équipements Sociaux
            </h4>
            <p className="text-sm text-purple-600 mb-3">
              Écoles, centres de santé, équipements sportifs et culturels
            </p>
            <div className="text-2xl font-bold text-purple-800">70%</div>
            <div className="text-sm text-purple-600">12 projets en cours</div>
          </div>
        </div>
      </div>

      {/* Synthèse et perspectives */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-eye text-teal-500 mr-2"></i>
          Synthèse et Perspectives 2045
        </h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <h4 className="font-bold text-gray-800 mb-3">Défis Identifiés</h4>
            <ul className="space-y-2 text-gray-600">
              <li className="flex items-start">
                <i className="fas fa-exclamation-triangle text-yellow-500 mr-2 mt-1"></i>
                Disparités de développement entre espaces
              </li>
              <li className="flex items-start">
                <i className="fas fa-exclamation-triangle text-yellow-500 mr-2 mt-1"></i>
                Pression sur les ressources naturelles
              </li>
              <li className="flex items-start">
                <i className="fas fa-exclamation-triangle text-yellow-500 mr-2 mt-1"></i>
                Besoin de renforcement des infrastructures
              </li>
              <li className="flex items-start">
                <i className="fas fa-exclamation-triangle text-yellow-500 mr-2 mt-1"></i>
                Coordination inter-espaces à améliorer
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-gray-800 mb-3">Opportunités</h4>
            <ul className="space-y-2 text-gray-600">
              <li className="flex items-start">
                <i className="fas fa-check-circle text-green-500 mr-2 mt-1"></i>
                Complémentarité des vocations territoriales
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-green-500 mr-2 mt-1"></i>
                Potentiel touristique et agricole important
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-green-500 mr-2 mt-1"></i>
                Position géographique stratégique
              </li>
              <li className="flex items-start">
                <i className="fas fa-check-circle text-green-500 mr-2 mt-1"></i>
                Dynamique de coopération régionale
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SRATSpaces;

