import React from 'react';

const Header = () => {
  return (
    <header className="pdr-gradient text-white shadow-lg">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
              <i className="fas fa-chart-line text-2xl text-white"></i>
            </div>
            <div>
              <h1 className="text-2xl font-bold">Tableau de Bord PDR</h1>
              <p className="text-sm opacity-90">Région de Béni Mellal-Khénifra</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="text-sm opacity-90">Dernière mise à jour</p>
              <p className="text-sm font-semibold">Juillet 2025</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;

