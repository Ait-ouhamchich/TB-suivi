import React from 'react';

const Reports = () => {
  const reports = [
    {
      title: 'Rapport Annuel 2024',
      type: 'Rapport de performance',
      date: 'Décembre 2024',
      size: '2.4 MB',
      pages: 45,
      status: 'Publié',
      icon: 'fas fa-file-pdf',
      color: 'red'
    },
    {
      title: 'Évaluation Mi-Parcours',
      type: 'Évaluation externe',
      date: 'Juin 2024',
      size: '1.8 MB',
      pages: 32,
      status: 'Publié',
      icon: 'fas fa-file-alt',
      color: 'blue'
    },
    {
      title: 'Tableau de Bord Q4 2024',
      type: 'Rapport trimestriel',
      date: 'Janvier 2025',
      size: '950 KB',
      pages: 18,
      status: 'Publié',
      icon: 'fas fa-chart-bar',
      color: 'green'
    },
    {
      title: 'Analyse Budgétaire 2024',
      type: 'Rapport financier',
      date: 'Novembre 2024',
      size: '1.2 MB',
      pages: 28,
      status: 'Publié',
      icon: 'fas fa-coins',
      color: 'orange'
    },
    {
      title: 'Rapport Q1 2025',
      type: 'Rapport trimestriel',
      date: 'En cours',
      size: '-',
      pages: '-',
      status: 'En préparation',
      icon: 'fas fa-clock',
      color: 'gray'
    },
    {
      title: 'Évaluation Impact Social',
      type: 'Étude thématique',
      date: 'Mars 2025',
      size: '-',
      pages: '-',
      status: 'Planifié',
      icon: 'fas fa-users',
      color: 'purple'
    }
  ];

  const reportTypes = [
    {
      type: 'Rapports Annuels',
      count: 3,
      description: 'Synthèse complète des résultats annuels',
      frequency: 'Annuelle',
      icon: 'fas fa-calendar-alt',
      color: 'blue'
    },
    {
      type: 'Rapports Trimestriels',
      count: 12,
      description: 'Suivi régulier des indicateurs clés',
      frequency: 'Trimestrielle',
      icon: 'fas fa-chart-line',
      color: 'green'
    },
    {
      type: 'Évaluations Externes',
      count: 2,
      description: 'Évaluations indépendantes par des experts',
      frequency: 'Selon besoins',
      icon: 'fas fa-search',
      color: 'purple'
    },
    {
      type: 'Études Thématiques',
      count: 8,
      description: 'Analyses approfondies par secteur',
      frequency: 'Variable',
      icon: 'fas fa-microscope',
      color: 'orange'
    }
  ];

  const kpis = [
    { label: 'Rapports publiés', value: '25', trend: '+3', color: 'blue' },
    { label: 'Téléchargements', value: '1,247', trend: '+156', color: 'green' },
    { label: 'Taux de satisfaction', value: '87%', trend: '+5%', color: 'purple' },
    { label: 'Délai moyen publication', value: '12j', trend: '-2j', color: 'orange' }
  ];

  const getColorClasses = (color) => {
    const colors = {
      blue: 'text-blue-600 bg-blue-100 border-blue-200',
      green: 'text-green-600 bg-green-100 border-green-200',
      purple: 'text-purple-600 bg-purple-100 border-purple-200',
      orange: 'text-orange-600 bg-orange-100 border-orange-200',
      red: 'text-red-600 bg-red-100 border-red-200',
      gray: 'text-gray-600 bg-gray-100 border-gray-200'
    };
    return colors[color] || 'text-gray-600 bg-gray-100 border-gray-200';
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Publié':
        return 'bg-green-100 text-green-800';
      case 'En préparation':
        return 'bg-yellow-100 text-yellow-800';
      case 'Planifié':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* En-tête de section */}
      <div className="section-header">
        <h2 className="text-3xl font-bold text-gray-800">Rapports et Documentation</h2>
        <p className="text-gray-600 mt-2">Accès aux rapports de suivi, évaluations et études thématiques</p>
      </div>

      {/* KPIs des rapports */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {kpis.map((kpi, index) => (
          <div key={index} className="pdr-card rounded-lg p-6 text-center pdr-shadow">
            <div className={`text-3xl font-bold mb-2 ${kpi.color === 'blue' ? 'text-blue-600' : 
              kpi.color === 'green' ? 'text-green-600' : 
              kpi.color === 'purple' ? 'text-purple-600' : 'text-orange-600'}`}>
              {kpi.value}
            </div>
            <div className="text-gray-600 mb-1">{kpi.label}</div>
            <div className={`text-xs font-medium ${kpi.trend.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
              {kpi.trend}
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Liste des rapports récents */}
        <div className="lg:col-span-2 pdr-card rounded-lg p-6 pdr-shadow">
          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-file-alt mr-2 pdr-accent"></i>
            Rapports Récents
          </h3>
          <div className="space-y-4">
            {reports.map((report, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getColorClasses(report.color)}`}>
                      <i className={report.icon}></i>
                    </div>
                    <div className="flex-1">
                      <h4 className="font-bold text-gray-800 mb-1">{report.title}</h4>
                      <p className="text-sm text-gray-600 mb-2">{report.type}</p>
                      <div className="flex items-center space-x-4 text-xs text-gray-500">
                        <span><i className="fas fa-calendar mr-1"></i>{report.date}</span>
                        {report.size !== '-' && <span><i className="fas fa-file mr-1"></i>{report.size}</span>}
                        {report.pages !== '-' && <span><i className="fas fa-file-alt mr-1"></i>{report.pages} pages</span>}
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col items-end space-y-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(report.status)}`}>
                      {report.status}
                    </span>
                    {report.status === 'Publié' && (
                      <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                        <i className="fas fa-download mr-1"></i>Télécharger
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Types de rapports */}
        <div className="pdr-card rounded-lg p-6 pdr-shadow">
          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-layer-group mr-2 pdr-accent"></i>
            Types de Rapports
          </h3>
          <div className="space-y-4">
            {reportTypes.map((type, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center mb-2">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center mr-3 ${getColorClasses(type.color)}`}>
                    <i className={`${type.icon} text-sm`}></i>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800 text-sm">{type.type}</h4>
                    <p className="text-xs text-gray-500">{type.frequency}</p>
                  </div>
                </div>
                <p className="text-xs text-gray-600 mb-2">{type.description}</p>
                <div className="text-right">
                  <span className="text-sm font-bold text-gray-800">{type.count}</span>
                  <span className="text-xs text-gray-500 ml-1">rapports</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Calendrier de publication */}
      <div className="pdr-card rounded-lg p-6 pdr-shadow">
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-calendar-check mr-2 pdr-accent"></i>
          Calendrier de Publication 2025
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-blue-600 mb-2">T1</div>
            <div className="text-sm font-medium text-gray-800 mb-1">Mars 2025</div>
            <div className="text-xs text-gray-600">Rapport Trimestriel</div>
            <div className="text-xs text-gray-600">Évaluation Impact Social</div>
          </div>
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-green-600 mb-2">T2</div>
            <div className="text-sm font-medium text-gray-800 mb-1">Juin 2025</div>
            <div className="text-xs text-gray-600">Rapport Trimestriel</div>
            <div className="text-xs text-gray-600">Évaluation Mi-Parcours</div>
          </div>
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-purple-600 mb-2">T3</div>
            <div className="text-sm font-medium text-gray-800 mb-1">Septembre 2025</div>
            <div className="text-xs text-gray-600">Rapport Trimestriel</div>
            <div className="text-xs text-gray-600">Étude Tourisme</div>
          </div>
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-orange-600 mb-2">T4</div>
            <div className="text-sm font-medium text-gray-800 mb-1">Décembre 2025</div>
            <div className="text-xs text-gray-600">Rapport Annuel</div>
            <div className="text-xs text-gray-600">Bilan Financier</div>
          </div>
        </div>
      </div>

      {/* Instructions d'accès */}
      <div className="pdr-card rounded-lg p-6 pdr-shadow">
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-info-circle mr-2 pdr-accent"></i>
          Accès aux Documents
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-bold text-gray-800 mb-2">Documents Publics</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li className="flex items-center">
                <i className="fas fa-check-circle text-green-500 mr-2"></i>
                Rapports annuels et trimestriels
              </li>
              <li className="flex items-center">
                <i className="fas fa-check-circle text-green-500 mr-2"></i>
                Synthèses exécutives
              </li>
              <li className="flex items-center">
                <i className="fas fa-check-circle text-green-500 mr-2"></i>
                Tableaux de bord publics
              </li>
              <li className="flex items-center">
                <i className="fas fa-check-circle text-green-500 mr-2"></i>
                Évaluations externes
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-gray-800 mb-2">Formats Disponibles</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li className="flex items-center">
                <i className="fas fa-file-pdf text-red-500 mr-2"></i>
                PDF (version complète)
              </li>
              <li className="flex items-center">
                <i className="fas fa-file-alt text-blue-500 mr-2"></i>
                Résumé exécutif
              </li>
              <li className="flex items-center">
                <i className="fas fa-chart-bar text-green-500 mr-2"></i>
                Données Excel
              </li>
              <li className="flex items-center">
                <i className="fas fa-presentation text-purple-500 mr-2"></i>
                Présentation PowerPoint
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;

