import React from 'react';

const StrategicAxes = () => {
  const axes = [
    {
      id: 1,
      name: 'Industrie, Commerce et Services',
      icon: 'fas fa-industry',
      progress: 75,
      budget: '450M MAD',
      projects: 23,
      status: 'En cours',
      color: 'blue'
    },
    {
      id: 2,
      name: 'Agriculture, Élevage et Eaux et Forêts',
      icon: 'fas fa-leaf',
      progress: 82,
      budget: '680M MAD',
      projects: 31,
      status: 'En cours',
      color: 'green'
    },
    {
      id: 3,
      name: 'Tourisme',
      icon: 'fas fa-umbrella-beach',
      progress: 65,
      budget: '320M MAD',
      projects: 18,
      status: 'En cours',
      color: 'purple'
    },
    {
      id: 4,
      name: 'Artisanat et Économie Solidaire',
      icon: 'fas fa-hands-helping',
      progress: 58,
      budget: '180M MAD',
      projects: 15,
      status: 'En cours',
      color: 'orange'
    },
    {
      id: 5,
      name: 'Urbanisme et Aménagement du Territoire',
      icon: 'fas fa-city',
      progress: 71,
      budget: '520M MAD',
      projects: 27,
      status: 'En cours',
      color: 'indigo'
    },
    {
      id: 6,
      name: 'Culture',
      icon: 'fas fa-theater-masks',
      progress: 63,
      budget: '150M MAD',
      projects: 12,
      status: 'En cours',
      color: 'pink'
    },
    {
      id: 7,
      name: 'Éducation et Formation',
      icon: 'fas fa-graduation-cap',
      progress: 78,
      budget: '720M MAD',
      projects: 35,
      status: 'En cours',
      color: 'teal'
    },
    {
      id: 8,
      name: 'Sport',
      icon: 'fas fa-running',
      progress: 55,
      budget: '120M MAD',
      projects: 14,
      status: 'En cours',
      color: 'red'
    }
  ];

  const getColorClasses = (color) => {
    const colors = {
      blue: 'text-blue-600 bg-blue-100',
      green: 'text-green-600 bg-green-100',
      purple: 'text-purple-600 bg-purple-100',
      orange: 'text-orange-600 bg-orange-100',
      indigo: 'text-indigo-600 bg-indigo-100',
      pink: 'text-pink-600 bg-pink-100',
      teal: 'text-teal-600 bg-teal-100',
      red: 'text-red-600 bg-red-100'
    };
    return colors[color] || 'text-gray-600 bg-gray-100';
  };

  const getProgressColor = (progress) => {
    if (progress >= 80) return 'bg-green-500';
    if (progress >= 60) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="space-y-6">
      {/* En-tête de section */}
      <div className="section-header">
        <h2 className="text-3xl font-bold text-gray-800">Axes Stratégiques du PDR</h2>
        <p className="text-gray-600 mt-2">Suivi détaillé de l'avancement par axe stratégique</p>
      </div>

      {/* Statistiques globales */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-blue-600 mb-2">13</div>
          <div className="text-gray-600">Axes Stratégiques</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-green-600 mb-2">175</div>
          <div className="text-gray-600">Projets Total</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-purple-600 mb-2">3.2B</div>
          <div className="text-gray-600">Budget Total (MAD)</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-orange-600 mb-2">68%</div>
          <div className="text-gray-600">Avancement Moyen</div>
        </div>
      </div>

      {/* Grille des axes stratégiques */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {axes.map((axe) => (
          <div key={axe.id} className="pdr-card rounded-lg p-6 pdr-shadow hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getColorClasses(axe.color)}`}>
                <i className={`${axe.icon} text-xl`}></i>
              </div>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                axe.status === 'En cours' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
              }`}>
                {axe.status}
              </span>
            </div>

            <h3 className="text-lg font-bold text-gray-800 mb-3 line-clamp-2">{axe.name}</h3>

            <div className="space-y-3">
              {/* Barre de progression */}
              <div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm font-medium text-gray-600">Avancement</span>
                  <span className="text-sm font-bold text-gray-800">{axe.progress}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-300 ${getProgressColor(axe.progress)}`}
                    style={{ width: `${axe.progress}%` }}
                  ></div>
                </div>
              </div>

              {/* Informations détaillées */}
              <div className="grid grid-cols-2 gap-4 pt-3 border-t border-gray-200">
                <div>
                  <div className="text-xs text-gray-500 mb-1">Budget</div>
                  <div className="text-sm font-semibold text-gray-800">{axe.budget}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500 mb-1">Projets</div>
                  <div className="text-sm font-semibold text-gray-800">{axe.projects}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Graphique de répartition budgétaire */}
      <div className="pdr-card rounded-lg p-6 pdr-shadow">
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-chart-pie mr-2 pdr-accent"></i>
          Répartition Budgétaire par Axe
        </h3>
        <div className="text-center text-gray-600">
          <i className="fas fa-chart-pie text-6xl mb-4 pdr-accent"></i>
          <p>Graphique interactif de répartition budgétaire</p>
          <p className="text-sm mt-2">Les visualisations détaillées seront intégrées dans la prochaine phase</p>
        </div>
      </div>
    </div>
  );
};

export default StrategicAxes;

