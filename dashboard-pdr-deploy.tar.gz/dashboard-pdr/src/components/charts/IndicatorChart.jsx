import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const IndicatorChart = ({ data, title }) => {
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: title,
        font: {
          size: 16,
          weight: 'bold'
        }
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  const chartData = {
    labels: data.labels,
    datasets: [
      {
        label: 'Valeur Actuelle',
        data: data.current,
        borderColor: '#2e86c1',
        backgroundColor: 'rgba(46, 134, 193, 0.2)',
        tension: 0.1,
      },
      {
        label: 'Objectif',
        data: data.target,
        borderColor: '#48c9b0',
        backgroundColor: 'rgba(72, 201, 176, 0.2)',
        borderDash: [5, 5],
        tension: 0.1,
      },
    ],
  };

  return (
    <div style={{ height: '300px' }}>
      <Line options={options} data={chartData} />
    </div>
  );
};

export default IndicatorChart;

