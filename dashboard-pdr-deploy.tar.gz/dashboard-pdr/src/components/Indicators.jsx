import React from 'react';
import indicatorsVisualization from '../assets/indicators_visualization.png';

const Indicators = () => {
  const indicatorCategories = [
    {
      category: 'Économie',
      icon: 'fas fa-chart-line',
      color: 'blue',
      indicators: [
        { name: 'Taux de croissance des entreprises', current: '8.5%', target: '10%', status: 'progress' },
        { name: 'Chiffre d\'affaires global', current: '2.1B MAD', target: '2.5B MAD', status: 'progress' },
        { name: 'Emplois créés', current: '12,450', target: '15,000', status: 'progress' }
      ]
    },
    {
      category: 'Agriculture',
      icon: 'fas fa-leaf',
      color: 'green',
      indicators: [
        { name: 'Rendement moyen oliviers', current: '3.2 T/ha', target: '4.0 T/ha', status: 'progress' },
        { name: 'Fermes durables', current: '22%', target: '30%', status: 'progress' },
        { name: 'Surface irriguée', current: '45,000 ha', target: '55,000 ha', status: 'progress' }
      ]
    },
    {
      category: 'Social',
      icon: 'fas fa-users',
      color: 'purple',
      indicators: [
        { name: 'Taux de scolarisation', current: '87%', target: '95%', status: 'progress' },
        { name: 'Couverture médicale', current: '78%', target: '85%', status: 'progress' },
        { name: 'Accès à l\'eau potable', current: '92%', target: '98%', status: 'good' }
      ]
    },
    {
      category: 'Infrastructure',
      icon: 'fas fa-road',
      color: 'orange',
      indicators: [
        { name: 'Routes réhabilitées', current: '320 km', target: '500 km', status: 'progress' },
        { name: 'Électrification rurale', current: '94%', target: '98%', status: 'good' },
        { name: 'Projets d\'assainissement', current: '15', target: '25', status: 'progress' }
      ]
    }
  ];

  const getColorClasses = (color) => {
    const colors = {
      blue: 'text-blue-600 bg-blue-100 border-blue-200',
      green: 'text-green-600 bg-green-100 border-green-200',
      purple: 'text-purple-600 bg-purple-100 border-purple-200',
      orange: 'text-orange-600 bg-orange-100 border-orange-200'
    };
    return colors[color] || 'text-gray-600 bg-gray-100 border-gray-200';
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'good':
        return <i className="fas fa-check-circle text-green-500"></i>;
      case 'progress':
        return <i className="fas fa-clock text-yellow-500"></i>;
      case 'warning':
        return <i className="fas fa-exclamation-triangle text-red-500"></i>;
      default:
        return <i className="fas fa-minus-circle text-gray-500"></i>;
    }
  };

  const calculateProgress = (current, target) => {
    // Extraction des valeurs numériques pour le calcul
    const currentNum = parseFloat(current.replace(/[^\d.]/g, ''));
    const targetNum = parseFloat(target.replace(/[^\d.]/g, ''));
    return Math.min(100, Math.round((currentNum / targetNum) * 100));
  };

  return (
    <div className="space-y-6">
      {/* En-tête de section */}
      <div className="section-header">
        <h2 className="text-3xl font-bold text-gray-800">Indicateurs de Performance</h2>
        <p className="text-gray-600 mt-2">Suivi détaillé des indicateurs SMART par catégorie</p>
      </div>

      {/* Statistiques globales */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-blue-600 mb-2">26</div>
          <div className="text-gray-600">Indicateurs Total</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-green-600 mb-2">18</div>
          <div className="text-gray-600">En Progression</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-yellow-600 mb-2">6</div>
          <div className="text-gray-600">Objectifs Atteints</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-red-600 mb-2">2</div>
          <div className="text-gray-600">Nécessitent Attention</div>
        </div>
      </div>

      {/* Visualisation des indicateurs */}
      <div className="pdr-card rounded-lg p-6 pdr-shadow mb-8">
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-chart-bar mr-2 pdr-accent"></i>
          Visualisation des Indicateurs Clés
        </h3>
        <div className="text-center">
          <img 
            src={indicatorsVisualization} 
            alt="Visualisation des indicateurs" 
            className="w-full max-w-4xl mx-auto rounded-lg border-2 pdr-border"
          />
        </div>
      </div>

      {/* Indicateurs par catégorie */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {indicatorCategories.map((category, index) => (
          <div key={index} className="pdr-card rounded-lg p-6 pdr-shadow">
            <div className="flex items-center mb-4">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center mr-3 ${getColorClasses(category.color)}`}>
                <i className={category.icon}></i>
              </div>
              <h3 className="text-xl font-bold text-gray-800">{category.category}</h3>
            </div>

            <div className="space-y-4">
              {category.indicators.map((indicator, idx) => (
                <div key={idx} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-gray-800">{indicator.name}</span>
                    {getStatusIcon(indicator.status)}
                  </div>
                  
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-600">Actuel: <strong>{indicator.current}</strong></span>
                    <span className="text-sm text-gray-600">Cible: <strong>{indicator.target}</strong></span>
                  </div>

                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="progress-bar h-2 rounded-full transition-all duration-300"
                      style={{ width: `${calculateProgress(indicator.current, indicator.target)}%` }}
                    ></div>
                  </div>
                  
                  <div className="text-right mt-1">
                    <span className="text-xs text-gray-500">
                      {calculateProgress(indicator.current, indicator.target)}% de l'objectif
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Méthodologie SMART */}
      <div className="pdr-card rounded-lg p-6 pdr-shadow">
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-bullseye mr-2 pdr-accent"></i>
          Méthodologie SMART
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-blue-600 mb-2">S</div>
            <div className="text-sm font-medium text-gray-800 mb-1">Spécifiques</div>
            <div className="text-xs text-gray-600">Objectifs clairs et précis</div>
          </div>
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-green-600 mb-2">M</div>
            <div className="text-sm font-medium text-gray-800 mb-1">Mesurables</div>
            <div className="text-xs text-gray-600">Quantifiables et vérifiables</div>
          </div>
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-purple-600 mb-2">A</div>
            <div className="text-sm font-medium text-gray-800 mb-1">Atteignables</div>
            <div className="text-xs text-gray-600">Réalistes et faisables</div>
          </div>
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-orange-600 mb-2">R</div>
            <div className="text-sm font-medium text-gray-800 mb-1">Réalistes</div>
            <div className="text-xs text-gray-600">Adaptés au contexte</div>
          </div>
          <div className="text-center p-4 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-red-600 mb-2">T</div>
            <div className="text-sm font-medium text-gray-800 mb-1">Temporels</div>
            <div className="text-xs text-gray-600">Délais définis</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Indicators;

