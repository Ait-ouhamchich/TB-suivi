import React from 'react';
import BudgetChart from './charts/BudgetChart';
import ProgressChart from './charts/ProgressChart';
import { budgetDistributionData, axesProgressData, sectorsData } from '../data/mockData';

const StrategicAxesEnhanced = () => {
  const axes = [
    {
      id: 1,
      name: 'Industrie, Commerce et Services',
      icon: 'fas fa-industry',
      progress: 75,
      budget: '450M MAD',
      projects: 23,
      status: 'En cours',
      color: 'blue',
      description: 'Développement du tissu industriel et commercial régional'
    },
    {
      id: 2,
      name: 'Agriculture, Élevage et Eaux et Forêts',
      icon: 'fas fa-leaf',
      progress: 82,
      budget: '680M MAD',
      projects: 31,
      status: 'En cours',
      color: 'green',
      description: 'Modernisation et durabilité du secteur agricole'
    },
    {
      id: 3,
      name: 'Tourisme',
      icon: 'fas fa-umbrella-beach',
      progress: 65,
      budget: '320M MAD',
      projects: 18,
      status: 'En cours',
      color: 'purple',
      description: 'Valorisation du patrimoine touristique régional'
    },
    {
      id: 4,
      name: 'Artisanat et Économie Solidaire',
      icon: 'fas fa-hands-helping',
      progress: 58,
      budget: '180M MAD',
      projects: 15,
      status: 'En cours',
      color: 'orange',
      description: 'Promotion de l\'artisanat traditionnel et de l\'économie sociale'
    },
    {
      id: 5,
      name: 'Urbanisme et Aménagement du Territoire',
      icon: 'fas fa-city',
      progress: 71,
      budget: '520M MAD',
      projects: 27,
      status: 'En cours',
      color: 'indigo',
      description: 'Planification urbaine et aménagement territorial'
    },
    {
      id: 6,
      name: 'Culture',
      icon: 'fas fa-theater-masks',
      progress: 63,
      budget: '150M MAD',
      projects: 12,
      status: 'En cours',
      color: 'pink',
      description: 'Préservation et promotion du patrimoine culturel'
    }
  ];

  const getColorClasses = (color) => {
    const colors = {
      blue: 'text-blue-600 bg-blue-100',
      green: 'text-green-600 bg-green-100',
      purple: 'text-purple-600 bg-purple-100',
      orange: 'text-orange-600 bg-orange-100',
      indigo: 'text-indigo-600 bg-indigo-100',
      pink: 'text-pink-600 bg-pink-100'
    };
    return colors[color] || 'text-gray-600 bg-gray-100';
  };

  const getProgressColor = (progress) => {
    if (progress >= 80) return 'bg-green-500';
    if (progress >= 60) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const totalBudget = axes.reduce((sum, axe) => sum + parseInt(axe.budget.replace(/[^\d]/g, '')), 0);
  const totalProjects = axes.reduce((sum, axe) => sum + axe.projects, 0);
  const averageProgress = Math.round(axes.reduce((sum, axe) => sum + axe.progress, 0) / axes.length);

  return (
    <div className="space-y-6">
      {/* En-tête de section */}
      <div className="section-header">
        <h2 className="text-3xl font-bold text-gray-800">Axes Stratégiques du PDR</h2>
        <p className="text-gray-600 mt-2">Suivi détaillé de l'avancement par axe stratégique</p>
      </div>

      {/* Statistiques globales */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-blue-600 mb-2">13</div>
          <div className="text-gray-600">Axes Stratégiques</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-green-600 mb-2">{totalProjects}</div>
          <div className="text-gray-600">Projets Total</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-purple-600 mb-2">{(totalBudget / 1000).toFixed(1)}B</div>
          <div className="text-gray-600">Budget Total (MAD)</div>
        </div>
        <div className="pdr-card rounded-lg p-6 text-center pdr-shadow">
          <div className="text-3xl font-bold text-orange-600 mb-2">{averageProgress}%</div>
          <div className="text-gray-600">Avancement Moyen</div>
        </div>
      </div>

      {/* Graphiques de synthèse */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <div className="pdr-card rounded-lg p-6 pdr-shadow">
          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-chart-bar mr-2 pdr-accent"></i>
            Avancement par Axe
          </h3>
          <ProgressChart 
            data={axesProgressData} 
            title="Progression des Axes Stratégiques (%)"
          />
        </div>

        <div className="pdr-card rounded-lg p-6 pdr-shadow">
          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
            <i className="fas fa-chart-pie mr-2 pdr-accent"></i>
            Répartition Budgétaire
          </h3>
          <BudgetChart 
            data={budgetDistributionData} 
            title="Budget par Secteur (M MAD)"
          />
        </div>
      </div>

      {/* Grille des axes stratégiques */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {axes.map((axe) => (
          <div key={axe.id} className="pdr-card rounded-lg p-6 pdr-shadow hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getColorClasses(axe.color)}`}>
                <i className={`${axe.icon} text-xl`}></i>
              </div>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                axe.status === 'En cours' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
              }`}>
                {axe.status}
              </span>
            </div>

            <h3 className="text-lg font-bold text-gray-800 mb-2">{axe.name}</h3>
            <p className="text-sm text-gray-600 mb-4">{axe.description}</p>

            <div className="space-y-3">
              {/* Barre de progression */}
              <div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm font-medium text-gray-600">Avancement</span>
                  <span className="text-sm font-bold text-gray-800">{axe.progress}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-300 ${getProgressColor(axe.progress)}`}
                    style={{ width: `${axe.progress}%` }}
                  ></div>
                </div>
              </div>

              {/* Informations détaillées */}
              <div className="grid grid-cols-2 gap-4 pt-3 border-t border-gray-200">
                <div>
                  <div className="text-xs text-gray-500 mb-1">Budget</div>
                  <div className="text-sm font-semibold text-gray-800">{axe.budget}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500 mb-1">Projets</div>
                  <div className="text-sm font-semibold text-gray-800">{axe.projects}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Tableau de performance */}
      <div className="pdr-card rounded-lg p-6 pdr-shadow">
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
          <i className="fas fa-table mr-2 pdr-accent"></i>
          Performance par Secteur
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-semibold text-gray-800">Secteur</th>
                <th className="text-center py-3 px-4 font-semibold text-gray-800">Projets</th>
                <th className="text-center py-3 px-4 font-semibold text-gray-800">Budget (M MAD)</th>
                <th className="text-center py-3 px-4 font-semibold text-gray-800">Avancement</th>
                <th className="text-center py-3 px-4 font-semibold text-gray-800">Statut</th>
              </tr>
            </thead>
            <tbody>
              {sectorsData.map((sector, index) => (
                <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium text-gray-800">{sector.name}</td>
                  <td className="py-3 px-4 text-center">{sector.projects}</td>
                  <td className="py-3 px-4 text-center">{sector.budget}</td>
                  <td className="py-3 px-4 text-center">
                    <div className="flex items-center justify-center">
                      <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                        <div 
                          className={`h-2 rounded-full ${getProgressColor(sector.progress)}`}
                          style={{ width: `${sector.progress}%` }}
                        ></div>
                      </div>
                      <span className="text-xs font-medium">{sector.progress}%</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      sector.progress >= 80 ? 'bg-green-100 text-green-800' :
                      sector.progress >= 60 ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {sector.progress >= 80 ? 'Excellent' :
                       sector.progress >= 60 ? 'Satisfaisant' : 'À améliorer'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default StrategicAxesEnhanced;

