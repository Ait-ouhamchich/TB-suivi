import React, { useState } from 'react';
import './App.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

// Composants PDR
import Header from './components/Header';
import Navigation from './components/Navigation';
import OverviewEnhanced from './components/OverviewEnhanced';
import StrategicAxesEnhanced from './components/StrategicAxesEnhanced';
import IndicatorsEnhanced from './components/IndicatorsEnhanced';
import Map from './components/Map';
import Governance from './components/Governance';
import Reports from './components/Reports';

// Composants SRAT
import SRATNavigation from './components/srat/SRATNavigation';
import SRATOverview from './components/srat/SRATOverview';
import SRATStrategicAxes from './components/srat/SRATStrategicAxes';
import SRATIndicators from './components/srat/SRATIndicators';
import SRATSpaces from './components/srat/SRATSpaces';

// Composant de sélection
import DashboardSelector from './components/DashboardSelector';

function App() {
  const [currentDashboard, setCurrentDashboard] = useState('PDR');
  const [activePDRSection, setActivePDRSection] = useState('overview');
  const [activeSRATSection, setActiveSRATSection] = useState('overview');

  const renderPDRContent = () => {
    switch (activePDRSection) {
      case 'overview':
        return <OverviewEnhanced />;
      case 'strategic-axes':
        return <StrategicAxesEnhanced />;
      case 'indicators':
        return <IndicatorsEnhanced />;
      case 'map':
        return <Map />;
      case 'governance':
        return <Governance />;
      case 'reports':
        return <Reports />;
      default:
        return <OverviewEnhanced />;
    }
  };

  const renderSRATContent = () => {
    switch (activeSRATSection) {
      case 'overview':
        return <SRATOverview />;
      case 'strategic-axes':
        return <SRATStrategicAxes />;
      case 'indicators':
        return <SRATIndicators />;
      case 'spaces':
        return <SRATSpaces />;
      case 'governance':
        return <Governance />;
      case 'reports':
        return <Reports />;
      default:
        return <SRATOverview />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header principal */}
      <Header />
      
      {/* Sélecteur de tableau de bord */}
      <DashboardSelector 
        currentDashboard={currentDashboard} 
        setCurrentDashboard={setCurrentDashboard} 
      />
      
      {/* Navigation spécifique au tableau de bord */}
      {currentDashboard === 'PDR' ? (
        <Navigation 
          activeSection={activePDRSection} 
          setActiveSection={setActivePDRSection} 
        />
      ) : (
        <SRATNavigation 
          activeSection={activeSRATSection} 
          setActiveSection={setActiveSRATSection} 
        />
      )}
      
      {/* Contenu principal */}
      <main className="container mx-auto px-6 py-8">
        {currentDashboard === 'PDR' ? renderPDRContent() : renderSRATContent()}
      </main>
      
      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 mt-12">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-bold mb-4">
                {currentDashboard === 'PDR' ? 'Programme de Développement Régional' : 'Schéma Régional d\'Aménagement du Territoire'}
              </h3>
              <p className="text-gray-300">
                {currentDashboard === 'PDR' 
                  ? 'Suivi et évaluation du développement économique et social de la région Béni Mellal-Khénifra'
                  : 'Suivi et évaluation de l\'aménagement territorial et du développement durable de la région Béni Mellal-Khénifra'
                }
              </p>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">Liens Utiles</h3>
              <ul className="space-y-2 text-gray-300">
                <li><a href="#" className="hover:text-white">Région Béni Mellal-Khénifra</a></li>
                <li><a href="#" className="hover:text-white">Ministère de l'Intérieur</a></li>
                <li><a href="#" className="hover:text-white">Documentation</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">Contact</h3>
              <div className="text-gray-300 space-y-2">
                <p><i className="fas fa-map-marker-alt mr-2"></i>Béni Mellal, Maroc</p>
                <p><i className="fas fa-phone mr-2"></i>+212 523 XXX XXX</p>
                <p><i className="fas fa-envelope mr-2"></i>contact@benimellalkhenifra.ma</p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-300">
            <p>&copy; 2024 Région Béni Mellal-Khénifra. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;

