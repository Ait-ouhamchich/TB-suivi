// Données simulées pour le tableau de bord SRAT

export const sratOverviewData = {
  kpis: {
    espacesProjects: 4,
    avancementGlobal: 72,
    indicateursSuivis: 18,
    populationCouverte: 2.8
  },
  
  avancementEspaces: {
    labels: ['DIR', 'PLATEAU', 'PLAINE', 'MONTAGNE'],
    datasets: [{
      label: 'Avancement (%)',
      data: [78, 85, 68, 65],
      backgroundColor: 'rgba(72, 201, 176, 0.8)',
      borderColor: 'rgba(72, 201, 176, 1)',
      borderWidth: 1
    }]
  },

  repartitionInvestissements: {
    labels: ['Infrastructures', 'Développement Rural', 'Environnement', 'Équipements Publics', 'Tourisme', 'Industrie'],
    datasets: [{
      data: [35, 25, 15, 12, 8, 5],
      backgroundColor: [
        'rgba(72, 201, 176, 0.8)',
        'rgba(52, 152, 219, 0.8)',
        'rgba(46, 125, 50, 0.8)',
        'rgba(255, 193, 7, 0.8)',
        'rgba(233, 30, 99, 0.8)',
        'rgba(156, 39, 176, 0.8)'
      ]
    }]
  }
};

export const sratStrategicAxesData = {
  kpis: {
    orientationsStrategiques: 5,
    projetsStructurants: 85,
    budgetTotal: 2.8,
    avancementMoyen: 72
  },

  avancementOrientations: {
    labels: ['Développement Économique', 'Aménagement Territorial', 'Développement Humain', 'Environnement', 'Gouvernance'],
    datasets: [{
      label: 'Avancement (%)',
      data: [78, 82, 65, 70, 68],
      backgroundColor: 'rgba(72, 201, 176, 0.8)',
      borderColor: 'rgba(72, 201, 176, 1)',
      borderWidth: 1
    }]
  },

  orientations: [
    {
      id: 1,
      titre: 'Développement Économique Intégré',
      icon: 'fas fa-industry',
      color: 'blue',
      avancement: 78,
      objectifs: [
        'Diversification de la base économique régionale',
        'Valorisation des potentialités agricoles et touristiques',
        'Développement de l\'industrie agroalimentaire',
        'Renforcement du secteur des services'
      ],
      projetsClés: 'Zones industrielles, parcs technologiques, circuits touristiques'
    },
    {
      id: 2,
      titre: 'Aménagement Territorial Équilibré',
      icon: 'fas fa-map',
      color: 'green',
      avancement: 82,
      objectifs: [
        'Renforcement de l\'armature urbaine',
        'Désenclavement des zones rurales',
        'Amélioration de la connectivité territoriale',
        'Équilibre urbain-rural'
      ],
      projetsClés: 'Routes régionales, centres urbains, équipements publics'
    },
    {
      id: 3,
      titre: 'Développement Humain et Social',
      icon: 'fas fa-graduation-cap',
      color: 'purple',
      avancement: 65,
      objectifs: [
        'Amélioration de l\'accès à l\'éducation et à la santé',
        'Réduction des disparités sociales',
        'Renforcement des capacités humaines',
        'Promotion de l\'emploi et de l\'inclusion'
      ],
      projetsClés: 'Écoles, centres de santé, centres de formation'
    },
    {
      id: 4,
      titre: 'Préservation Environnementale',
      icon: 'fas fa-leaf',
      color: 'green-600',
      avancement: 70,
      objectifs: [
        'Protection des ressources naturelles',
        'Gestion durable de l\'eau',
        'Préservation de la biodiversité',
        'Lutte contre la dégradation des sols'
      ],
      projetsClés: 'Stations d\'épuration, aires protégées, reboisement'
    },
    {
      id: 5,
      titre: 'Gouvernance et Participation',
      icon: 'fas fa-users-cog',
      color: 'orange',
      avancement: 68,
      objectifs: [
        'Renforcement de la gouvernance territoriale',
        'Amélioration de la participation citoyenne',
        'Coordination inter-institutionnelle',
        'Transparence et redevabilité'
      ],
      projetsClés: 'Plateformes participatives, systèmes d\'information, formations'
    }
  ],

  espacesProjects: [
    { nom: 'DIR', description: 'Espace de développement intégré rural', avancement: 78, color: 'blue' },
    { nom: 'PLATEAU', description: 'Espace plateau et montagnes', avancement: 85, color: 'green' },
    { nom: 'PLAINE', description: 'Espace plaine agricole', avancement: 68, color: 'yellow' },
    { nom: 'MONTAGNE', description: 'Espace montagnard', avancement: 65, color: 'purple' }
  ]
};

export const sratIndicatorsData = {
  kpis: {
    indicateursTotal: 18,
    enBonneVoie: 12,
    objectifsAtteints: 4,
    necessitentAttention: 2
  },

  evolutionIndicateurs: {
    labels: ['2021', '2022', '2023', '2024', '2025 (proj)', '2026 (proj)', '2027 (obj)'],
    datasets: [
      {
        label: 'Taux d\'Équipement Rural (%)',
        data: [45, 52, 58, 65, 70, 75, 80],
        borderColor: 'rgba(72, 201, 176, 1)',
        backgroundColor: 'rgba(72, 201, 176, 0.1)',
        tension: 0.4
      },
      {
        label: 'Objectif',
        data: [45, 50, 55, 60, 65, 70, 80],
        borderColor: 'rgba(72, 201, 176, 0.5)',
        backgroundColor: 'transparent',
        borderDash: [5, 5],
        tension: 0.4
      }
    ]
  },

  indicateursParDomaine: {
    infrastructures: [
      { nom: 'Taux de Désenclavement', valeur: 78, objectif: 95, color: 'blue' },
      { nom: 'Couverture Réseau Routier', valeur: 85, objectif: 90, color: 'green' },
      { nom: 'Accès Internet Haut Débit', valeur: 62, objectif: 85, color: 'yellow' }
    ],
    environnement: [
      { nom: 'Accès à l\'Eau Potable', valeur: 92, objectif: 98, color: 'blue-600' },
      { nom: 'Traitement des Eaux Usées', valeur: 68, objectif: 85, color: 'green-600' },
      { nom: 'Couverture Forestière', valeur: 45, objectif: 55, color: 'red', attention: true }
    ],
    urbain: [
      { nom: 'Taux d\'Urbanisation', valeur: 58, objectif: 65, color: 'purple' },
      { nom: 'Équipements Publics', valeur: 72, objectif: 85, color: 'indigo' },
      { nom: 'Espaces Verts Urbains', valeur: 35, objectif: 50, color: 'pink' }
    ],
    economique: [
      { nom: 'PIB Régional (Croissance)', valeur: 4.2, objectif: 5, color: 'orange', unite: '%' },
      { nom: 'Taux d\'Emploi', valeur: 68, objectif: 75, color: 'teal' },
      { nom: 'Investissements Privés', valeur: 82, objectif: 90, color: 'cyan' }
    ]
  }
};

export const sratSpacesData = {
  kpis: {
    espacesProjects: 4,
    population: 2.8,
    projetsTotal: 85,
    avancementMoyen: 72
  },

  espaces: [
    {
      id: 'dir',
      nom: 'DIR',
      titre: 'Développement Intégré Rural',
      description: 'Espace dédié au développement rural intégré, valorisant les potentialités agricoles et pastorales.',
      icon: 'fas fa-seedling',
      color: 'blue',
      avancement: 78,
      population: '650K',
      superficie: '8,500 km²',
      communes: 45,
      projets: 18,
      projetsClés: 'Modernisation agricole, centres ruraux, routes de désenclavement'
    },
    {
      id: 'plateau',
      nom: 'PLATEAU',
      titre: 'Plateau et Montagnes',
      description: 'Espace montagnard et de plateau, axé sur le tourisme écologique et la préservation environnementale.',
      icon: 'fas fa-mountain',
      color: 'green',
      avancement: 85,
      population: '420K',
      superficie: '6,200 km²',
      communes: 38,
      projets: 22,
      projetsClés: 'Circuits touristiques, aires protégées, infrastructures écotouristiques'
    },
    {
      id: 'plaine',
      nom: 'PLAINE',
      titre: 'Plaine Agricole',
      description: 'Espace de plaine à vocation agricole intensive, pôle de production et d\'agro-industrie.',
      icon: 'fas fa-wheat',
      color: 'yellow',
      avancement: 68,
      population: '1.2M',
      superficie: '4,800 km²',
      communes: 68,
      projets: 28,
      projetsClés: 'Zones industrielles, irrigation moderne, centres logistiques'
    },
    {
      id: 'montagne',
      nom: 'MONTAGNE',
      titre: 'Espace Montagnard',
      description: 'Espace de haute montagne, axé sur la conservation, le tourisme de montagne et l\'économie forestière.',
      icon: 'fas fa-tree',
      color: 'green-600',
      avancement: 65,
      population: '530K',
      superficie: '9,100 km²',
      communes: 44,
      projets: 17,
      projetsClés: 'Stations de montagne, reboisement, gestion des bassins versants'
    }
  ],

  projetsTransversaux: [
    {
      nom: 'Infrastructures de Transport',
      description: 'Réseau routier régional, liaisons inter-espaces, désenclavement rural',
      icon: 'fas fa-road',
      color: 'blue',
      avancement: 82,
      projets: 15
    },
    {
      nom: 'Connectivité Numérique',
      description: 'Couverture internet, services numériques, e-gouvernance',
      icon: 'fas fa-wifi',
      color: 'green',
      avancement: 75,
      projets: 8
    },
    {
      nom: 'Équipements Sociaux',
      description: 'Écoles, centres de santé, équipements sportifs et culturels',
      icon: 'fas fa-graduation-cap',
      color: 'purple',
      avancement: 70,
      projets: 12
    }
  ]
};

