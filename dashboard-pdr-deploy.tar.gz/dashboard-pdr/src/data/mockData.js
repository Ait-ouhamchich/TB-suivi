// Données simulées pour le tableau de bord PDR Béni Mellal-Khénifra

export const axesProgressData = {
  labels: [
    'Industrie',
    'Agriculture',
    'Tourisme',
    'Artisanat',
    'Urbanisme',
    'Culture',
    'Éducation',
    'Sport'
  ],
  values: [75, 82, 65, 58, 71, 63, 78, 55]
};

export const budgetDistributionData = {
  labels: [
    'Éducation et Formation',
    'Agriculture et Eaux',
    'Infrastructure',
    'Industrie et Commerce',
    'Santé',
    'Tourisme',
    'Artisanat',
    'Culture et Sport'
  ],
  values: [720, 680, 520, 450, 380, 320, 180, 270]
};

export const indicatorTrendsData = {
  labels: ['2022', '2023', '2024', '2025 (proj)', '2026 (proj)', '2027 (obj)'],
  current: [5.2, 6.8, 8.5, 9.2, 9.8, 10.0],
  target: [6.0, 7.0, 8.0, 9.0, 9.5, 10.0]
};

export const provincesData = [
  {
    name: 'Béni Mellal',
    population: 946018,
    projects: 45,
    budget: 1200,
    progress: 72,
    coordinates: { lat: 32.3373, lng: -6.3498 }
  },
  {
    name: 'Khénifra',
    population: 597818,
    projects: 38,
    budget: 890,
    progress: 68,
    coordinates: { lat: 32.9351, lng: -5.6681 }
  },
  {
    name: 'Khouribga',
    population: 499144,
    projects: 32,
    budget: 750,
    progress: 75,
    coordinates: { lat: 32.8811, lng: -6.9063 }
  },
  {
    name: 'Azilal',
    population: 504501,
    projects: 35,
    budget: 680,
    progress: 65,
    coordinates: { lat: 31.9647, lng: -6.5707 }
  },
  {
    name: 'Fquih Ben Salah',
    population: 338221,
    projects: 25,
    budget: 480,
    progress: 70,
    coordinates: { lat: 32.5019, lng: -6.6919 }
  }
];

export const kpiData = {
  totalProjects: 175,
  completedProjects: 89,
  ongoingProjects: 86,
  totalBudget: 4000, // en millions MAD
  executedBudget: 2720, // en millions MAD
  beneficiaries: 2800000,
  jobsCreated: 12450,
  averageProgress: 68
};

export const sectorsData = [
  { name: 'Agriculture', projects: 38, budget: 680, progress: 82 },
  { name: 'Éducation', projects: 35, budget: 720, progress: 78 },
  { name: 'Infrastructure', projects: 32, budget: 520, progress: 71 },
  { name: 'Industrie', projects: 28, budget: 450, progress: 75 },
  { name: 'Santé', projects: 25, budget: 380, progress: 73 },
  { name: 'Tourisme', projects: 17, budget: 320, progress: 65 }
];

export const timelineData = [
  { year: 2022, phase: 'Lancement', status: 'completed', progress: 100 },
  { year: 2023, phase: 'Mise en œuvre initiale', status: 'completed', progress: 100 },
  { year: 2024, phase: 'Accélération', status: 'completed', progress: 100 },
  { year: 2025, phase: 'Consolidation', status: 'ongoing', progress: 45 },
  { year: 2026, phase: 'Finalisation', status: 'planned', progress: 0 },
  { year: 2027, phase: 'Évaluation finale', status: 'planned', progress: 0 }
];

export const indicatorsData = {
  economic: [
    { name: 'Taux de croissance des entreprises', current: 8.5, target: 10, unit: '%' },
    { name: 'Chiffre d\'affaires global', current: 2.1, target: 2.5, unit: 'B MAD' },
    { name: 'Emplois créés', current: 12450, target: 15000, unit: 'emplois' }
  ],
  social: [
    { name: 'Taux de scolarisation', current: 87, target: 95, unit: '%' },
    { name: 'Couverture médicale', current: 78, target: 85, unit: '%' },
    { name: 'Accès à l\'eau potable', current: 92, target: 98, unit: '%' }
  ],
  environmental: [
    { name: 'Fermes durables', current: 22, target: 30, unit: '%' },
    { name: 'Déchets traités', current: 65, target: 80, unit: '%' },
    { name: 'Énergies renouvelables', current: 35, target: 50, unit: '%' }
  ]
};

